/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jiraconnector.validators;

import javax.faces.component.*;
import javax.faces.context.*;
import javax.faces.convert.*;
/**
 *
 * @author a.shalin
 */
@FacesConverter(value="isoConverter")
public class IsoConverter implements Converter {
    @Override
    public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2) {
        try {
            return (String)arg2;
        } catch (Exception ex) {
//            System.out.println(ex.getStackTrace());
            return null;
        }
    }
    
    @Override
    public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2) {
        try {
            String s=(String) arg2;
            return new String (s.getBytes ("iso-8859-1"), "UTF-8");
        } catch (Exception ex) {
//            System.out.println(ex.getStackTrace());
            return null;
        }
    }
}
