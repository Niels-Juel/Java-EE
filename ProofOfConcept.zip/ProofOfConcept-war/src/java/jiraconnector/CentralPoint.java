/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector;

import jiraconnector.entries.jira.*;
import jiraconnector.entries.jirasup.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.*;
import javax.annotation.PreDestroy;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.json.Json;
import javax.json.JsonReader;
import javax.json.JsonStructure;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import jiraconnector.entries.*;
import jiraconnector.entries.jirasup.CwdUserSup;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

/**
 * Holds all critical user session parameters
 * @author a.shalin
 */
@Named
@SessionScoped
public class CentralPoint implements Serializable {
//    @PersistenceContext(unitName = "overwatch", type=PersistenceContextType.TRANSACTION)
    private EntityManager entityManagerOverwatch, entityManager, entityManagerSup; 
    
    private final CloseableHttpClient httpClient;
    private final HttpClientContext context;
    private final HttpHost targetHost;
    private String user, password, mockUser;
    private List<CwdUser> usersList;
    private List<CwdUserSup> usersListSup;
    private final Map<String, CwdUser> usersMap;
    private final Map<String, CwdUserSup> usersMapSup;
    private final List<String> projectsList, projectsListSup;
    private final Map<Long, Project> projectsMap;
    private final Map<Long, ProjectSup> projectsMapSup;
    private final Map<Long, Jiraissue> issueCache;
    private final Map<Long, JiraissueSup> issueCacheSup;
    private final Map<String, Issuestatus> issueStatusMap;
    private final Map<String, IssuestatusSup> issueStatusMapSup;
    private final Map<Long, Customfield> customFieldsMap;
    private final Map<Long, CustomfieldSup> customFieldsMapSup;
    private final Map<Long, Customfieldoption> customFieldOptionsMap;
    private final Map<Long, CustomfieldoptionSup> customFieldOptionsMapSup;
//    private final Map<Long, Map<String, String>> issuesCustomFieldsMap;
    private final List<String> organizationList, projectHMAList;
    private final Map<String, DevelopmentGroup> devGroupsMap;
    private final Map<String, DevelopmentGroup> devGroupsMapByLead;
    private final List<String> devGroupsList;
    private final TimeZone timeZone;
    private final Set<String> superUsers;

    public EntityManager getEntityManager() {
        return entityManager;
    }

    public EntityManager getEntityManagerOverwatch() {
        return entityManagerOverwatch;
    }

    public EntityManager getEntityManagerSup() {
        return entityManagerSup;
    }

    public CloseableHttpClient getHttpClient() {
        return httpClient;
    }

    public HttpClientContext getContext() {
        return context;
    }

    public HttpHost getTargetHost() {
        return targetHost;
    }

    public Map<Long, Project> getProjectsMap() {
        return projectsMap;
    }

    public List<String> getProjectsList() {
        return projectsList;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user.toLowerCase();
    }
    
    public String getPassword() {
        return "Blah-blah-blah!";
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<CwdUser> getUsersList() {
        return usersList;
    }

    public Map<String, CwdUser> getUsersMap() {
        return usersMap;
    }

    public Map<Long, Jiraissue> getIssueCache() {
        return issueCache;
    }

    public Map<String, Issuestatus> getIssueStatusMap() {
        return issueStatusMap;
    }

    public Map<Long, Customfield> getCustomFieldsMap() {
        return customFieldsMap;
    }

    public Map<Long, Customfieldoption> getCustomFieldOptionsMap() {
        return customFieldOptionsMap;
    }

//    public Map<Long, Map<String, String>> getIssuesCustomFieldsMap() {
//        return issuesCustomFieldsMap;
//    }

    public List<String> getOrganizationList() {
        return organizationList;
    }

    public List<String> getProjectHMAList() {
        return projectHMAList;
    }

    public Map<String, DevelopmentGroup> getDevGroupsMap() {
        return devGroupsMap;
    }

    public List<String> getDevGroupsList() {
        return devGroupsList;
    }

    public Set<String> getSuperUsers() {
        return superUsers;
    }

    public Map<String, DevelopmentGroup> getDevGroupsMapByLead() {
        return devGroupsMapByLead;
    }

    public String getMockUser() {
        return mockUser;
    }

    public void setMockUser(String mockUser) {
        this.mockUser = mockUser.toLowerCase();
    }

    public List<CwdUserSup> getUsersListSup() {
        return usersListSup;
    }

    public Map<String, CwdUserSup> getUsersMapSup() {
        return usersMapSup;
    }

    public List<String> getProjectsListSup() {
        return projectsListSup;
    }

    public Map<Long, ProjectSup> getProjectsMapSup() {
        return projectsMapSup;
    }

    public Map<Long, JiraissueSup> getIssueCacheSup() {
        return issueCacheSup;
    }

    public Map<String, IssuestatusSup> getIssueStatusMapSup() {
        return issueStatusMapSup;
    }

    public Map<Long, CustomfieldSup> getCustomFieldsMapSup() {
        return customFieldsMapSup;
    }

    public Map<Long, CustomfieldoptionSup> getCustomFieldOptionsMapSup() {
        return customFieldOptionsMapSup;
    }
    
    /**
     * Creates a new instance of CentralPoint
     */
    public CentralPoint() {
        context=HttpClientContext.create();
        httpClient=HttpClients.createDefault();
        targetHost=new HttpHost("jira.rambler.ru", 443, "https");
        usersMap=new HashMap<>();
        issueCache=new HashMap<>();
        issueStatusMap=new HashMap<>();
        projectsMap=new HashMap<>();
        customFieldsMap=new HashMap<>();
        customFieldOptionsMap=new HashMap<>();
//        issuesCustomFieldsMap=new HashMap<>();
        organizationList=new ArrayList<>();
        projectHMAList=new ArrayList<>();
        projectsList=new ArrayList<>();
        devGroupsMap=new HashMap<>();
        devGroupsList=new ArrayList<>();
        this.timeZone=ToolBox.getTimeZone();
        superUsers=new HashSet<>();
        devGroupsMapByLead=new HashMap<>();
        
        usersMapSup=new HashMap<>();
        projectsMapSup=new HashMap<>();
        projectsListSup=new ArrayList<>();
        issueCacheSup=new HashMap<>();
        issueStatusMapSup=new HashMap<>();
        customFieldsMapSup=new HashMap<>();
        customFieldOptionsMapSup=new HashMap<>();
//        mockUser="a.sokolov";
    }    
    
    /**
     * Authorizes users's http session 
     * @return
     * @throws IOException 
     */
    public String authorize() throws IOException {
        Credentials defaultCreds=new UsernamePasswordCredentials(user, password);
        
        CredentialsProvider credsProvider=new BasicCredentialsProvider();
        credsProvider.setCredentials(new AuthScope(targetHost.getHostName(), targetHost.getPort()), defaultCreds);
        
        //Create AutoCash instance
        AuthCache authCache=new BasicAuthCache();
        BasicScheme basicAuth=new BasicScheme();
        authCache.put(targetHost, basicAuth);
        
        //Add AuthCache to the execution context
        //HttpClientContext context=HttpClientContext.create();
        context.setCredentialsProvider(credsProvider);
        context.setAuthCache(authCache);
        
        HttpGet httpGet=new HttpGet("/rest/api/2/issue/TESTWORK-7");
        CloseableHttpResponse response=httpClient.execute(targetHost, httpGet, context);
        
        if (response.getStatusLine().getStatusCode()==200) {
            mockUser=user.toLowerCase();
//            mockUser="a.sokolov";
            initialize();
            return "workloadreport";
        } else {
            return null;
        }
    }
    
    public JsonStructure submitGetRequest(String path) {
        JsonStructure requestedEntry=null;
        
        try {
            HttpGet httpGet=new HttpGet(path);
            CloseableHttpResponse response=httpClient.execute(targetHost, httpGet, context);

            HttpEntity entity=response.getEntity(); 
            InputStream input=entity.getContent();

            JsonReader jsonReader=Json.createReader(input);
            requestedEntry=jsonReader.read();
            
            jsonReader.close();
            input.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }        
        return requestedEntry;
    }

    private void initialize() throws IOException{
        //Connect to Jira DB
        Map<String, String> propertiesJira = new HashMap<>();
//        propertiesJira.put("javax.persistence.jdbc.user", "ashalin");
//        propertiesJira.put("javax.persistence.jdbc.password", "vfVkqM93Ga3hTk6w");
        
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("JiraToolBox-ejbPU", propertiesJira);    
        entityManager = emf.createEntityManager();
        
        //Connect to Overwatch DB
//        Map<String, String> propertiesOverwatch = new HashMap<>();
//        propertiesOverwatch.put("javax.persistence.jdbc.user", "shalin");
//        propertiesOverwatch.put("javax.persistence.jdbc.password", "F9937kl");
//        
//        EntityManagerFactory emfOverwatch = Persistence.createEntityManagerFactory("overwatch", propertiesOverwatch);    
//        entityManagerOverwatch = emfOverwatch.createEntityManager();
        
        //Connect to Jira Sup 
//        Map<String, String> propertiesSup = new HashMap<>();
//        propertiesSup.put("javax.persistence.jdbc.user", "ashalin");
//        propertiesSup.put("javax.persistence.jdbc.password", "mxBCg0eEQUZyj5mf");
//
//        EntityManagerFactory emfSup = Persistence.createEntityManagerFactory("jirasup", propertiesSup);
//        entityManagerSup=emfSup.createEntityManager();
        
        fillResources();
    }
    
    private synchronized void fillResources() throws IOException{
        usersMap.clear();
        issueCache.clear();
        issueStatusMap.clear();
        projectsMap.clear();
        customFieldsMap.clear();
        customFieldOptionsMap.clear();
//        issuesCustomFieldsMap.clear();
        organizationList.clear();
        projectHMAList.clear();
        projectsList.clear();
        devGroupsMap.clear();
        devGroupsList.clear();
        superUsers.clear();

        //Super Users
        superUsers.addAll(Arrays.asList("a.shalin", "p.eremin", "a.solomennik", "d.malov", "dmalov", 
                "tturner", "t.turner", "v.vatrak", "v.patyk", "vp", "r.shiryaev", "n.ermakov"));
        
        //CwdUser General
        Query query = entityManager.createNamedQuery("CwdUser.findAll");
        usersList=query.getResultList();
        
        for (CwdUser cwdUser: usersList) {
            usersMap.put(cwdUser.getUserName().toLowerCase(), cwdUser);
        }
        
        //CwdUser Sup
        query = entityManagerSup.createNamedQuery("CwdUserSup.findAll");
        usersListSup=query.getResultList();
//        
        for (CwdUserSup cwdUserSup: usersListSup) {
            usersMapSup.put(cwdUserSup.getUserName().toLowerCase(), cwdUserSup);
        }
        
        //Issuestatus General
        query = entityManager.createNamedQuery("Issuestatus.findAll");
        List<Issuestatus> issueStatusList=query.getResultList();
        for (Issuestatus issueStatus: issueStatusList) {
            issueStatusMap.put(issueStatus.getId(), issueStatus);
        }
        
        //Issuestatus Sup
        query = entityManagerSup.createNamedQuery("IssuestatusSup.findAll");
        List<IssuestatusSup> issueStatusListSup=query.getResultList();
        for (IssuestatusSup issueStatusSup: issueStatusListSup) {
            issueStatusMapSup.put(issueStatusSup.getId(), issueStatusSup);
        }

        //Customfield General
        query = entityManager.createNamedQuery("Customfield.findAll");
        List<Customfield> customFieldsList=query.getResultList();
        for (Customfield customField: customFieldsList) {
            customFieldsMap.put(customField.getId(), customField);
        }
        
        //Customfield Sup
        query = entityManagerSup.createNamedQuery("CustomfieldSup.findAll");
        List<CustomfieldSup> customFieldsListSup=query.getResultList();
        for (CustomfieldSup customFieldSup: customFieldsListSup) {
            customFieldsMapSup.put(customFieldSup.getId(), customFieldSup);
        }
        
        Set<String> projectHMASet=new HashSet<>();
        Set<String> organizationSet=new HashSet<>();
        projectHMAList.clear();
        organizationList.clear();
        
        query = entityManager.createNamedQuery("Customfieldoption.findAll");
        List<Customfieldoption> customFieldOptionsList=query.getResultList();
        for (Customfieldoption customFieldOption: customFieldOptionsList) {
            customFieldOptionsMap.put(customFieldOption.getId(), customFieldOption);
            if (customFieldOption.getCustomfield().longValue()==11900 && customFieldOption.getParentoptionid()==null) {
                organizationSet.add(customFieldOption.getCustomvalue());
            }
            if (customFieldOption.getCustomfield().longValue()==11900 && customFieldOption.getParentoptionid()!=null) {
                projectHMASet.add(customFieldOption.getCustomvalue());
            }
        }
        organizationList.addAll(organizationSet);
        projectHMAList.addAll(projectHMASet);
        Collections.sort(projectHMAList);
        Collections.sort(organizationList);
        
        //Filling Development Groups
        devGroupsList.clear();
        devGroupsMap.clear();
        
        //CMS
        DevelopmentGroup developmentGroup=new DevelopmentGroup();
        developmentGroup.setLead("a.lomakin");
        developmentGroup.getJiraProjectsSet().add("Единая система управления контентом");
        devGroupsMap.put("CMS", developmentGroup);
        devGroupsMapByLead.put(developmentGroup.getLead(), developmentGroup);
//        devGroupsList.add("CMS");
        
        //Мобильные приложения
        developmentGroup=new DevelopmentGroup();
        developmentGroup.setLead("a.chikunov");
        developmentGroup.getJiraProjectsSet().add("Mobile Platform Project");
        devGroupsMap.put("Мобильные приложения", developmentGroup);
        devGroupsMapByLead.put(developmentGroup.getLead(), developmentGroup);
//        devGroupsList.add("Мобильные приложения");
        
        //Афиша
        developmentGroup=new DevelopmentGroup();
        developmentGroup.setLead("a.sokolov");
        developmentGroup.getJiraProjectsSet().add("Nightparty");
        developmentGroup.getJiraProjectsSet().add("Афиша - МИР");
        developmentGroup.getJiraProjectsSet().add("Афиша-Партнеры");
        developmentGroup.getJiraProjectsSet().add("Сайт Афиши");
        developmentGroup.getJiraProjectsSet().add("Афиша-Пикник");
        developmentGroup.getJiraProjectsSet().add("Афиша-Рестораны");
        developmentGroup.getJiraProjectsSet().add("Афиша-Сериалы");
        developmentGroup.getJiraProjectsSet().add("Платформа Афиши");
        developmentGroup.getJiraProjectsSet().add("Афиша - ID");
        developmentGroup.getJiraProjectsSet().add("Афиша-Еда"); 
        devGroupsMap.put("Афиша", developmentGroup);
        devGroupsMapByLead.put(developmentGroup.getLead(), developmentGroup);
//        devGroupsList.add("Афиша");
        
        //Инфографика
        developmentGroup=new DevelopmentGroup();
        developmentGroup.setLead("p.shorokh");
        developmentGroup.getJiraProjectsSet().add("Infographics");
        devGroupsMap.put("Инфографика", developmentGroup);
        devGroupsMapByLead.put(developmentGroup.getLead(), developmentGroup);
//        devGroupsList.add("Инфографика");
        
        //Quto/Redigo
        developmentGroup=new DevelopmentGroup();
        developmentGroup.setLead("ikondrashov");
        developmentGroup.getJiraProjectsSet().add("QR / QUTO.RU");
        developmentGroup.getJiraProjectsSet().add("QR / REDIGO.RU");
        devGroupsMap.put("Quto/Redigo", developmentGroup);
        devGroupsMapByLead.put(developmentGroup.getLead(), developmentGroup);
        
        //Rambler
        developmentGroup=new DevelopmentGroup();
        developmentGroup.setLead("o.obolensky");
        developmentGroup.getJiraProjectsSet().add("Главная");
        developmentGroup.getJiraProjectsSet().add("Рамблер-Новости");
        developmentGroup.getJiraProjectsSet().add("Модель пользователя");
        developmentGroup.getJiraProjectsSet().add("Рамблер-Топ100");
        developmentGroup.getJiraProjectsSet().add("Рамблер Поиск");
        developmentGroup.getJiraProjectsSet().add("Рамблер-ID");
        developmentGroup.getJiraProjectsSet().add("Рамблер-Почта");
        developmentGroup.getJiraProjectsSet().add("Баннерная система - AdStat");
        developmentGroup.getJiraProjectsSet().add("Баннерная система - Rotor");
        developmentGroup.getJiraProjectsSet().add("Баннерная система - Бэк-офис");
        developmentGroup.getJiraProjectsSet().add("Баннерная система - Поддержка");
        developmentGroup.getJiraProjectsSet().add("Баннерная система – Green");
        developmentGroup.getJiraProjectsSet().add("Баннерная система – Сеть");
        developmentGroup.getJiraProjectsSet().add("Баннерная система – Статистика и отчетность");
//        developmentGroup.getJiraProjectsSet().add("TESTWORK");        
        devGroupsMap.put("Rambler", developmentGroup);
        devGroupsMapByLead.put(developmentGroup.getLead(), developmentGroup);
        
        //Рамблер-Касса
        developmentGroup=new DevelopmentGroup();
        developmentGroup.setLead("d.lyashenko");
        developmentGroup.getJiraProjectsSet().add("Рамблер-Касса");
        devGroupsMap.put("Рамблер-Касса", developmentGroup);
        devGroupsMapByLead.put(developmentGroup.getLead(), developmentGroup);
        
        //Чемпионат
        developmentGroup=new DevelopmentGroup();
        developmentGroup.setLead("lfadeeva");
        developmentGroup.getWatchers().addAll(Arrays.asList("pgolovin"));
        developmentGroup.getJiraProjectsSet().add("Sport / Championat.COM / Maintenance");
        developmentGroup.getJiraProjectsSet().add("Sport / Fanat.ru");
        developmentGroup.getJiraProjectsSet().add("Sport / Championat / Server");
        developmentGroup.getJiraProjectsSet().add("Sport / Championat / Design");
        devGroupsMap.put("Чемпионат", developmentGroup);
        devGroupsMapByLead.put(developmentGroup.getLead(), developmentGroup);
        devGroupsMapByLead.put("pgolovin", developmentGroup);

        for (Map.Entry<String, DevelopmentGroup> entry : devGroupsMap.entrySet()) {
//            System.out.println(entry.getKey() + "/" + entry.getValue().getLead());
            if (superUsers.contains(mockUser) || mockUser.equalsIgnoreCase(entry.getValue().getLead()) || entry.getValue().getWatchers().contains(mockUser)) {
                devGroupsList.add(entry.getKey());
            }
        }
        
        Collections.sort(devGroupsList);
        
        //Projects General
        query = entityManager.createNamedQuery("Project.findAll");
        List<Project> jiraProjectsList = query.getResultList();
        for (Project project: jiraProjectsList) {
            projectsMap.put(project.getId(), project);
            if (superUsers.contains(mockUser) || project.getLead().equalsIgnoreCase(mockUser) 
                    || (devGroupsMapByLead.get(mockUser)!=null && devGroupsMapByLead.get(mockUser).getJiraProjectsSet().contains(project.getPname()))) {
                projectsList.add(project.getPname());
            }
        }
        
        //Projects Sup
        query = entityManagerSup.createNamedQuery("ProjectSup.findAll");
        List<ProjectSup> jiraProjectsListSup = query.getResultList();
        for (ProjectSup projectSup: jiraProjectsListSup) {
            projectsMapSup.put(projectSup.getId(), projectSup);
            if (superUsers.contains(mockUser) || projectSup.getLead().equalsIgnoreCase(mockUser) 
                    || (devGroupsMapByLead.get(mockUser)!=null && devGroupsMapByLead.get(mockUser).getJiraProjectsSet().contains(projectSup.getPname()))) {
                projectsList.add(projectSup.getPname());
            }
        }
    }    
    
    public TimeZone getTimeZone() {
        return this.timeZone;
    }
    
    public String logout() {
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        return "index";
    }
    
    @PreDestroy
    private void cleanUp() {
//        System.out.println("Closing entity manager");
        entityManager.close();
    }
}
