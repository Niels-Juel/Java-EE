/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector;

import jiraconnector.entries.jira.*;
import jiraconnector.entries.jirasup.*;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.PostConstruct;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.Query;
import jiraconnector.entries.jirasup.JiraissueSup;

/**
 *
 * @author a.shalin
 */
@Named
@ViewScoped
public class WorkloadReport implements Serializable{
    @Inject
    private CentralPoint centralPoint;
    private String filterUserPattern;
    private final List<String> filteredUserList;
    private List<String> selectedUsersList, selectedWorkAreaList, selectedProjectsHMAList, selectedOrganizationsList;
    private final Map<String, String> filteredUserMap;
    private Date startPeriod, endPeriod;
    private final List<ReportEntry> reportList;
    private List<Worklog> jiraWorklog;
    private List<WorklogSup> jiraWorklogSup;
    private final List<UserReportBlock> detailedReportByUsers;
    private final List<ProjectReportBlock> detailedReportByProjects;
    private String dateFormat;
    private boolean isFullReportVisible, isDetailedByUsersReportVisible, isDetailedByProjectsReportVisible, isSortByUserAsc, 
            isSortByTaskNameAsc, isSortByWorkAreaAsc, isSortByOrganizationAsc, isSortByDevHMAAsc, isSortByPlatformAsc,
            isSortByRoleAsc, isSortByDevTypeAsc, isSortByDevFormAsc, isSortByDevGroupAsc;
    private List<String> selectedDevGroups;
    private List<String> chosenUsers; 
    private final List<String> chosenUsersFullList;
    private final Set<String> chosenUsersFullSet;

    public CentralPoint getCentralPoint() {
        return centralPoint;
    }

    public String getFilterUserPattern() {
        return filterUserPattern;
    }

    public List<String> getFilteredUserList() throws IOException {
        filterUsers();
        return filteredUserList;
    }

    public Date getStartPeriod() {
        return startPeriod;
    }

    public Date getEndPeriod() {
        return endPeriod;
    }

    public List<ReportEntry> getReportList() {
        return reportList;
    }

    public List<UserReportBlock> getDetailedReportByUsers() {
        return detailedReportByUsers;
    }

    public List<ProjectReportBlock> getDetailedReportByProjects() {
        return detailedReportByProjects;
    }

    public void setFilterUserPattern(String filterUserPattern) {
        this.filterUserPattern = filterUserPattern;
    }

    public List<String> getSelectedProjectsHMAList() {
        return selectedProjectsHMAList;
    }

    public void setSelectedProjectsHMAList(List<String> selectedProjectsHMAList) {
        this.selectedProjectsHMAList = selectedProjectsHMAList;
    }

    public List<String> getSelectedOrganizationsList() {
        return selectedOrganizationsList;
    }

    public void setSelectedOrganizationsList(List<String> selectedOrganizationsList) {
        this.selectedOrganizationsList = selectedOrganizationsList;
    }

    public List<String> getSelectedUsersList() {
        return selectedUsersList;
    }

    public void setSelectedUsersList(List<String> selectedUsersList) {
        this.selectedUsersList = selectedUsersList;
    }

    public List<String> getSelectedWorkAreaList() {
        return selectedWorkAreaList;
    }

    public void setSelectedWorkAreaList(List<String> selectedWorkAreaList) {
        this.selectedWorkAreaList = selectedWorkAreaList;
    }

    public List<String> getSelectedDevGroups() {
        return selectedDevGroups;
    }

    public void setSelectedDevGroups(List<String> selectedDevGroups) {
        this.selectedDevGroups = selectedDevGroups;
    }

    public void setStartPeriod(Date startPeriod) {
        this.startPeriod = startPeriod;
    }

    public void setEndPeriod(Date endPeriod) {
        this.endPeriod = endPeriod;
    }

    public String getDateFormat() {
        return dateFormat;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    public boolean isIsFullReportVisible() {
        return isFullReportVisible;
    }

    public boolean isIsDetailedByUsersReportVisible() {
        return isDetailedByUsersReportVisible;
    }

    public boolean isIsDetailedByProjectsReportVisible() {
        return isDetailedByProjectsReportVisible;
    }

    public List<String> getChosenUsersFullList() {
        return chosenUsersFullList;
    }

    public List<String> getChosenUsers() {
        return chosenUsers;
    }

    public void setChosenUsers(List<String> chosenUsers) {
        this.chosenUsers = chosenUsers;
    }

    /**
     * Creates a new instance of WorkloadReport
     */
    public WorkloadReport() {
        filterUserPattern=null;
        filteredUserList=new ArrayList<>();
        filteredUserMap=new HashMap<>();
        reportList=new ArrayList<>();
        startPeriod=ToolBox.getFirstDateOfCurrentMonth();
        endPeriod=ToolBox.getLastDateOfCurrentMonth();
        detailedReportByUsers=new ArrayList<>();
        detailedReportByProjects=new ArrayList<>();
        chosenUsersFullList=new ArrayList<>();
        dateFormat="dd.MM.yyyy";
        
        isFullReportVisible=false; 
        isDetailedByUsersReportVisible=false;
        isDetailedByProjectsReportVisible=false;
        isSortByUserAsc=false;
        isSortByTaskNameAsc=false;
        isSortByWorkAreaAsc=false;
        isSortByOrganizationAsc=false;
        isSortByDevHMAAsc=false;
        isSortByPlatformAsc=false;
        isSortByRoleAsc=false;
        isSortByDevTypeAsc=false; 
        isSortByDevFormAsc=false;
        isSortByDevGroupAsc=false;
        
        chosenUsersFullSet=new HashSet<>();
        selectedWorkAreaList=new ArrayList<>();
    }
    
    public void performFullReport() {
        isFullReportVisible=true;
        isDetailedByUsersReportVisible=false;
        isDetailedByProjectsReportVisible=false;
        submitSearch();
        submitSearchSup();
    }

    public void fillReportDetailedByProjects() {
        isFullReportVisible=false;
        isDetailedByProjectsReportVisible=true;
        isDetailedByUsersReportVisible=false;
        detailedReportByProjects.clear();
        
        submitSearch();

        for (ReportEntry reportEntry: reportList) {
            if  (reportEntry.getDevHMA().isEmpty()) {
                continue;
            }
            
            ProjectReportBlock currentProjectReportBlock=null;
            
            for (ProjectReportBlock projectReportBlock: detailedReportByProjects) {
                if  (projectReportBlock.getProjectName().equals(reportEntry.getDevHMA())) {
                    currentProjectReportBlock=projectReportBlock;
                    currentProjectReportBlock.setLaborExpenditures(currentProjectReportBlock.getLaborExpenditures()+reportEntry.getLaborExpendituresActual());
                    currentProjectReportBlock.setLaborExpendituresPlanned(currentProjectReportBlock.getLaborExpendituresPlanned()+reportEntry.getLaborExpendituresPlanned());
                    break;
                }
            }
            if (currentProjectReportBlock==null) {
                currentProjectReportBlock=new ProjectReportBlock();
                currentProjectReportBlock.setProjectName(reportEntry.getDevHMA());
                currentProjectReportBlock.setLaborExpenditures(reportEntry.getLaborExpendituresActual());
                currentProjectReportBlock.setLaborExpendituresPlanned(reportEntry.getLaborExpendituresPlanned());
                detailedReportByProjects.add(currentProjectReportBlock);
            }
            
            ProjectReportEntry projectReportEntry=new ProjectReportEntry();
            projectReportEntry.setWorkArea(reportEntry.getWorkArea());
            projectReportEntry.setTaskName(reportEntry.getProjectName());
            projectReportEntry.setLaborExpenditures(reportEntry.getLaborExpendituresActual());
            projectReportEntry.setLaborExpendituresPlanned(reportEntry.getLaborExpendituresPlanned());
            projectReportEntry.setOrganization(reportEntry.getOrganization());
            projectReportEntry.setEmployeeName(reportEntry.getEmployeeName());
            projectReportEntry.setPlatform(reportEntry.getPlatform());
            projectReportEntry.setRole(reportEntry.getRole());
            projectReportEntry.setDevForm(reportEntry.getDevForm());
            projectReportEntry.setDevType(reportEntry.getDevType());
            
            currentProjectReportBlock.getProjectReportEntries().add(projectReportEntry);
        }
        
        for (ProjectReportBlock projectReportBlock: detailedReportByProjects) {
            Collections.sort(projectReportBlock.getProjectReportEntries());
        }
        
        Collections.sort(detailedReportByProjects);
    }
    
    public void fillReportDetailedByUsers() {
        detailedReportByUsers.clear();
        isFullReportVisible=false;
        isDetailedByProjectsReportVisible=false;
        isDetailedByUsersReportVisible=true;
        submitSearch();
        submitSearchSup();

        for (ReportEntry reportEntry: reportList) {
            UserReportBlock currentUserReportBlock=null;

            for (UserReportBlock userReportBlock:detailedReportByUsers) {
                if (userReportBlock.getUserDisplayName().equals(reportEntry.getEmployeeName())) {
                    currentUserReportBlock=userReportBlock; 
                    currentUserReportBlock.setLaborExpendituresPlanned(currentUserReportBlock.getLaborExpendituresPlanned()+reportEntry.getLaborExpendituresPlanned());
                    currentUserReportBlock.setLaborExpenditures(currentUserReportBlock.getLaborExpenditures()+reportEntry.getLaborExpendituresActual());
                    break;
                }
            }
            if (currentUserReportBlock==null) {
                currentUserReportBlock=new UserReportBlock(reportEntry.getEmployeeName());
                currentUserReportBlock.setLaborExpenditures(reportEntry.getLaborExpendituresActual());
                currentUserReportBlock.setLaborExpendituresPlanned(reportEntry.getLaborExpendituresPlanned());
                detailedReportByUsers.add(currentUserReportBlock);
            }

            UserReportEntry userReportEntry=new UserReportEntry();
            userReportEntry.setDevForm(reportEntry.getDevForm());
            userReportEntry.setDevGroup(reportEntry.getDevGroup());
            userReportEntry.setDevType(reportEntry.getDevType());
            userReportEntry.setWorkArea(reportEntry.getWorkArea());
            userReportEntry.setProjectName(reportEntry.getProjectName());
            userReportEntry.setOrganization(reportEntry.getOrganization());
            userReportEntry.setStartReportPeriod(reportEntry.getStartReportPeriod());
            userReportEntry.setEndReportPeriod(reportEntry.getEndReportPeriod());
            userReportEntry.setJiraIssueId(reportEntry.getJiraIssueId());
            userReportEntry.setUserDisplayName(reportEntry.getEmployeeUserName());
            userReportEntry.setLaborExpendure(reportEntry.getLaborExpendituresActual());
            userReportEntry.setLaborExpendurePlanned(reportEntry.getLaborExpendituresPlanned());
            userReportEntry.setDevHMA(reportEntry.getDevHMA());
            userReportEntry.setRole(reportEntry.getRole());
            userReportEntry.setPlatform(reportEntry.getPlatform());

            currentUserReportBlock.getUserReportEntries().add(userReportEntry);
        }
        
        Collections.sort(detailedReportByUsers);
    }
    
    private void fillJiraIssueCacheSup(WorklogSup worklogSup) {
        JiraissueSup jiraissueSup=centralPoint.getEntityManagerSup().find(JiraissueSup.class, worklogSup.getIssueid());
        centralPoint.getEntityManagerSup().detach(jiraissueSup);
        
        //Responsibility scopes
        String teamLead=centralPoint.getProjectsMapSup().get(jiraissueSup.getProject()).getLead();
        jiraissueSup.getEmploymentIntervals().add(new EmploymentInterval(teamLead, jiraissueSup.getCreated(), null));
        jiraissueSup.getCreated().setSeconds(0);
        
        int index=0;
        Query queryChangeGroup=centralPoint.getEntityManagerSup().createNamedQuery("ChangegroupSup.findByIssueid");
        queryChangeGroup.setParameter("issueid", jiraissueSup.getId());
        List<ChangegroupSup> changeGroupListSup=queryChangeGroup.getResultList();
        for (ChangegroupSup changeGroupItemSup: changeGroupListSup) {
            Long changeGroupdId=changeGroupItemSup.getId();
            Query queryChangeItems=centralPoint.getEntityManagerSup().createNamedQuery("ChangeitemSup.findByGroupidField");
            queryChangeItems.setParameter("groupid", changeGroupdId);
            queryChangeItems.setParameter("field", "assignee");
            List<ChangeitemSup> changeItemsListSup=queryChangeItems.getResultList();
            
            for (ChangeitemSup changeItemSup: changeItemsListSup) {
                if (changeItemSup.getOldvalue()!=null) {
                    jiraissueSup.getEmploymentIntervals().get(index).setEmployeeName(changeItemSup.getOldvalue());
                } else {
                    jiraissueSup.getEmploymentIntervals().get(index).setEmployeeName(teamLead);
                }
                jiraissueSup.getEmploymentIntervals().get(index).setEnd(changeGroupItemSup.getCreated());
                index++;
                jiraissueSup.getEmploymentIntervals().add(new EmploymentInterval(changeItemSup.getNewvalue(), changeGroupItemSup.getCreated(), null));
            }
        }
        
        jiraissueSup.getEmploymentIntervals().get(jiraissueSup.getEmploymentIntervals().size()-1).setEnd(new Date());
        
        if (jiraissueSup.getEmploymentIntervals().size()==1) {
            EmploymentInterval employmeymentInterval=jiraissueSup.getEmploymentIntervals().get(0);
            employmeymentInterval.setEmployeeName(jiraissueSup.getAssignee());
            employmeymentInterval.setStart(jiraissueSup.getCreated());
        }
        
        centralPoint.getIssueCacheSup().put(worklogSup.getIssueid(), jiraissueSup);
    }
    
    public void submitSearchSup() {
//        isFullReportVisible=true;
//        isDetailedByUsersReportVisible=false;
//        isDetailedByProjectsReportVisible=false;
        centralPoint.getIssueCacheSup().clear();
        
        Set<String> selectedUsersSet=new HashSet<>(selectedUsersList);
        
        if (startPeriod.after(endPeriod)) {
            Date swap=startPeriod; startPeriod=endPeriod; endPeriod=swap;
        }

        Set<String> selectedWorkAreasSet=new HashSet<>(selectedWorkAreaList);
        if (!selectedDevGroups.isEmpty()) {
            for (String devGroupName: selectedDevGroups) {
                selectedWorkAreasSet.addAll(centralPoint.getDevGroupsMap().get(devGroupName).getJiraProjectsSet());
            }
        }

//        reportList.clear();

        String baseRequest="SELECT worklogSup FROM WorklogSup worklogSup WHERE worklogSup.id IS NOT NULL";

        baseRequest+=(" AND worklogSup.startdate >= :startPeriod AND worklogSup.startdate <= :endPeriod ORDER BY worklogSup.id");

        Query query=centralPoint.getEntityManagerSup().createQuery(baseRequest);

        query.setParameter("startPeriod", startPeriod);
        query.setParameter("endPeriod", endPeriod);

        jiraWorklogSup=query.getResultList();

        for (WorklogSup worklogSup: jiraWorklogSup) {
            if (!centralPoint.getIssueCacheSup().containsKey(worklogSup.getIssueid())) {
                fillJiraIssueCacheSup(worklogSup);
            }

            JiraissueSup currentIssue=centralPoint.getIssueCacheSup().get(worklogSup.getIssueid());

//            if (centralPoint.getIssueCacheSup().get(worklogSup.getIssueid()).getAssignee()==null) {
//                continue;
//            } 

            //Checking user's role
            if (!centralPoint.getSuperUsers().contains(centralPoint.getMockUser()) 
                    && !centralPoint.getProjectsMapSup().get(currentIssue.getProject()).getLead().toLowerCase().equals(centralPoint.getMockUser()) 
                    && (centralPoint.getDevGroupsMapByLead().get(centralPoint.getMockUser())==null || !centralPoint.getDevGroupsMapByLead().get(centralPoint.getMockUser()).getJiraProjectsSet().contains(centralPoint.getProjectsMapSup().get(currentIssue.getProject()).getPname()))) {
                continue;
            }

            String trackedEmployee=worklogSup.getAuthor();
            String employeeDisplayName;
            try {
                employeeDisplayName=centralPoint.getUsersMapSup().get(trackedEmployee).getDisplayName();
            } catch (Exception ex) {
                System.out.println(trackedEmployee+" does not exist in the database SUP");
                continue;
            }
            
            
            if (selectedUsersSet.isEmpty() || !selectedUsersSet.isEmpty() && selectedUsersSet.contains(employeeDisplayName)) {
                
            } else {
                continue;
            }
            
            if (!selectedDevGroups.isEmpty() && selectedWorkAreasSet.contains(centralPoint.getProjectsMapSup().get(currentIssue.getProject()).getPname())
                    || selectedDevGroups.isEmpty()) {

            } else {
                continue;
            }

            ReportEntry reportEntry=null;
            for (ReportEntry currentReportEntry: reportList) {
//                if (!centralPoint.getIssueCache().containsKey(worklog.getIssueid())) {
//                    fillJiraIssueCache(worklog);
//                }


//                BREAKPOINT!!!!!!!!!!
                if ((currentReportEntry.getJiraIssueId()==worklogSup.getIssueid().longValue()) && (currentReportEntry.getEmployeeUserName().equals(trackedEmployee))) {
                    currentReportEntry.setLaborExpendituresActual(currentReportEntry.getLaborExpendituresActual()+worklogSup.getTimeworked());
                    reportEntry=currentReportEntry; continue;
                }
            }
            if (reportEntry==null) {
                reportEntry=new ReportEntry(worklogSup.getIssueid(), worklogSup.getAuthor(), worklogSup.getTimeworked());
//                reportEntry.setEmployeeName(centralPoint.getUsersMap().get(worklog.getAuthor()).getDisplayName());
//                reportEntry.setEmployeeUserName(worklog.getAuthor());

                //Adding Jira issue to the cache
//                if (!centralPoint.getIssueCache().containsKey(worklog.getIssueid())) {
//                    fillJiraIssueCache(worklog);
//                }
//
//                Jiraissue currentIssue=centralPoint.getIssueCache().get(worklog.getIssueid());

//                reportEntry.setEmployeeUserName(currentIssue.getAssignee());
//                for (EmploymentInterval employmentInterval: currentIssue.getEmploymentIntervals()) {
//                    if ((worklog.getStartdate().after(employmentInterval.getStart()) || worklog.getStartdate().equals(employmentInterval.getStart()))
//                            && (worklog.getStartdate().before(employmentInterval.getEnd()) || worklog.getStartdate().equals(employmentInterval.getEnd()))) {
//                        reportEntry.setEmployeeUserName(employmentInterval.getEmployeeName());
////                        for (CwdUser cwdUser: centralPoint.getUsersList()) {
////                            if (cwdUser.getUserName().equals(employmentInterval.getEmployeeName())) {
////                                reportEntry.setEmployeeName(cwdUser.getDisplayName())
////                            }
////                        }
//                        reportEntry.setEmployeeName(centralPoint.getUsersMap().get(employmentInterval.getEmployeeName()).getDisplayName());
//                        break;
//                    }
//                }

//                reportEntry.setEmployeeName(centralPoint.getUsersMap().get(currentIssue.getAssignee()).getDisplayName());


//                System.out.println(currentIssue.getPkey()+" "+trackedEmployee);
                reportEntry.setEmployeeId(centralPoint.getUsersMapSup().get(trackedEmployee).getId());
                reportEntry.setEmployeeUserName(trackedEmployee);
//                reportEntry.setEmployeeName(centralPoint.getUsersMap().get(trackedEmployee).getDisplayName());
                reportEntry.setEmployeeName(employeeDisplayName);

//                reportEntry.setRole(currentIssue.getCustomFields().get("Роль"));
//                reportEntry.setPlatform(currentIssue.getCustomFields().get("Платформа"));
//                reportEntry.setDevForm(currentIssue.getCustomFields().get("Вид разработки"));
//                reportEntry.setDevType(currentIssue.getCustomFields().get("Тип разработки"));
//                reportEntry.setDevHMA(currentIssue.getCustomFields().get("Разрабатываемый проект (НМА)"));
//                reportEntry.setOrganization(currentIssue.getCustomFields().get("Организация"));

                reportEntry.setProjectName(currentIssue.getPkey()+" "+currentIssue.getSummary());
                reportEntry.setStartReportPeriod(startPeriod);
                reportEntry.setEndReportPeriod(endPeriod);

                //Mock
//                reportEntry.setStartPlanned(worklog.getStartdate());

                //Start of work actual
                Query queryMisc=centralPoint.getEntityManagerSup().createNamedQuery("OsHistorystepSup.findByStatusEntryId");
                queryMisc.setParameter("entryId", currentIssue.getWorkflowId());
                queryMisc.setParameter("stepIds", Arrays.asList(3));
                queryMisc.setMaxResults(1);
                List<OsHistorystepSup> trackingIssueListSup=queryMisc.getResultList();
                if (!trackingIssueListSup.isEmpty()) {
                    reportEntry.setStartActual(trackingIssueListSup.get(0).getStartDate());
//                    trackingIssueList.get(0).getCaller();
                } else {
//                    System.out.println(currentIssue.getPkey()+" under watch");
                    Query queryMiscOtherwise=centralPoint.getEntityManagerSup().createNamedQuery("OsCurrentstepSup.findByEntryIdStepId");
                    queryMiscOtherwise.setParameter("entryId", currentIssue.getWorkflowId());
                    queryMiscOtherwise.setParameter("stepIds", Arrays.asList(3));

                    List<OsCurrentstepSup> currentIssueStatusListSup=queryMiscOtherwise.getResultList();
                    if (!currentIssueStatusListSup.isEmpty()) {
                        reportEntry.setStartActual(currentIssueStatusListSup.get(0).getStartDate());
//                        System.out.println(currentIssue.getPkey()+" resolved");
                    }
                }

                //Endt of work actual
                List<Integer> closedIssueStatus=new ArrayList<>();
                closedIssueStatus.add(5); closedIssueStatus.add(6);
                queryMisc=centralPoint.getEntityManagerSup().createNamedQuery("OsCurrentstepSup.findByEntryIdStepId");
                queryMisc.setParameter("entryId", currentIssue.getWorkflowId());
                queryMisc.setParameter("stepIds", closedIssueStatus);
                List<OsCurrentstepSup> currentIssueStatusListSup=queryMisc.getResultList();
                for (OsCurrentstepSup currentStatusSup: currentIssueStatusListSup) {
                    reportEntry.setEndActual(currentStatusSup.getStartDate());
                }

                //End of work planned
                reportEntry.setEndPlanned(currentIssue.getDuedate());
                reportEntry.setLaborExpendituresPlanned(currentIssue.getTimeoriginalestimate());

                //Work area a.k.a. Jira Project
                reportEntry.setWorkArea(centralPoint.getProjectsMapSup().get(currentIssue.getProject()).getPname());
                for (String devGroupName: centralPoint.getDevGroupsList()) {
                    if (centralPoint.getDevGroupsMap().get(devGroupName).getJiraProjectsSet().contains(reportEntry.getWorkArea())) {
                        reportEntry.setDevGroup(devGroupName);
                        break;
                    }
                }

                reportList.add(reportEntry);
            }
        }
    }
    
    private void submitSearch() {
        centralPoint.getIssueCache().clear();
        
        if (selectedUsersList.isEmpty()) {
            selectedUsersList.addAll(chosenUsersFullList);
        }
        
        Set<String> selectedUsersSet=new HashSet<>(selectedUsersList);
        Set<String> selectedWorkAreasSet=new HashSet<>(selectedWorkAreaList);
        Set<String> selectedOrganizationsSet=new HashSet<>(selectedOrganizationsList);
        Set<String> selectedProjectsHMASet=new HashSet<>(selectedProjectsHMAList);
        
//        for (String user: selectedUsersSet) {
//            System.out.println(user);
//        }
        
        if (!selectedDevGroups.isEmpty()) {
            for (String devGroupName: selectedDevGroups) {
                selectedWorkAreasSet.addAll(centralPoint.getDevGroupsMap().get(devGroupName).getJiraProjectsSet());
            }
        }
        
        if (startPeriod.after(endPeriod)) {
            Date swap=startPeriod; startPeriod=endPeriod; endPeriod=swap;
        }
        
        startPeriod.setHours(6); startPeriod.setMinutes(1);
        endPeriod.setHours(23); endPeriod.setMinutes(59);
        
        reportList.clear();
        
        String baseRequest="SELECT worklog FROM Worklog worklog WHERE worklog.id IS NOT NULL";
        
        baseRequest+=(" AND worklog.startdate >= :startPeriod AND worklog.startdate <= :endPeriod ORDER BY worklog.id");
        
        Query query=centralPoint.getEntityManager().createQuery(baseRequest);
        
        query.setParameter("startPeriod", startPeriod);
        query.setParameter("endPeriod", endPeriod);
        
        jiraWorklog=query.getResultList();
        
        for (Worklog worklog: jiraWorklog) {
            if (!centralPoint.getIssueCache().containsKey(worklog.getIssueid())) {
                fillJiraIssueCache(worklog);
            }
            
            Jiraissue currentIssue=centralPoint.getIssueCache().get(worklog.getIssueid());
            
            if (centralPoint.getIssueCache().get(worklog.getIssueid()).getAssignee()==null) {
                continue;
            } 
            
            String trackedEmployee=getUserFromTrackLog(currentIssue, worklog).toLowerCase();
//            System.out.println(currentIssue.getPkey()+" "+trackedEmployee);
            String employeeDisplayName;
            try {
                employeeDisplayName=centralPoint.getUsersMap().get(trackedEmployee).getDisplayName();
            } catch (Exception ex) {
                System.out.println(trackedEmployee+" doesn't exist in the database Rambler");
                continue;
            }
            
            if (selectedUsersSet.isEmpty() || !selectedUsersSet.isEmpty() && selectedUsersSet.contains(employeeDisplayName)) {
                
            } else {
                continue;
            }
            
            //Checking user's role
            if (!centralPoint.getSuperUsers().contains(centralPoint.getMockUser()) 
                    && !centralPoint.getProjectsMap().get(currentIssue.getProject()).getLead().toLowerCase().equals(centralPoint.getMockUser()) 
                    && (centralPoint.getDevGroupsMapByLead().get(centralPoint.getMockUser())==null || !centralPoint.getDevGroupsMapByLead().get(centralPoint.getMockUser()).getJiraProjectsSet().contains(centralPoint.getProjectsMap().get(currentIssue.getProject()).getPname()))) {
                continue;
            }
            
//            if (!selectedProjectsHMASet.isEmpty() && currentIssue.getCustomFields().get("Разрабатываемый проект (НМА)")!=null 
//                    && selectedProjectsHMASet.contains(currentIssue.getCustomFields().get("Разрабатываемый проект (НМА)"))) {
//            
//            } else continue;
            
//            if ((!selectedUsersList.isEmpty() && selectedUsersSet.contains((centralPoint.getUsersMap().get(trackedEmployee).getDisplayName())))
//                    || (!selectedWorkAreaList.isEmpty() || !selectedDevGroups.isEmpty()) && selectedWorkAreasSet.contains(centralPoint.getProjectsMap().get(currentIssue.getProject()).getPname())
//                    || !selectedOrganizationsList.isEmpty() && currentIssue.getCustomFields().get("Организация")!=null && selectedOrganizationsSet.contains(currentIssue.getCustomFields().get("Организация"))
//                    || !selectedProjectsHMASet.isEmpty() && currentIssue.getCustomFields().get("Разрабатываемый проект (НМА)")!=null && selectedProjectsHMASet.contains(currentIssue.getCustomFields().get("Разрабатываемый проект (НМА)"))
//                    //|| !selectedDevGroups.isEmpty() && centralPoint.getProjectsMap().get(currentIssue.getPkey()).getPkey()
//                    || selectedWorkAreaList.isEmpty() && selectedOrganizationsList.isEmpty() && selectedDevGroups.isEmpty() && selectedProjectsHMAList.isEmpty()){
//                
//            } else {
//                continue;
//            }
            
            ReportEntry reportEntry=null;
            for (ReportEntry currentReportEntry: reportList) {
//                if (!centralPoint.getIssueCache().containsKey(worklog.getIssueid())) {
//                    fillJiraIssueCache(worklog);
//                }
                

//                BREAKPOINT!!!!!!!!!!
                if ((currentReportEntry.getJiraIssueId()==worklog.getIssueid().longValue()) && (currentReportEntry.getEmployeeUserName().equals(trackedEmployee))) {
                    currentReportEntry.setLaborExpendituresActual(currentReportEntry.getLaborExpendituresActual()+worklog.getTimeworked());
                    reportEntry=currentReportEntry; continue;
                }
            }
            if (reportEntry==null) {
                reportEntry=new ReportEntry(worklog.getIssueid(), worklog.getAuthor(), worklog.getTimeworked());
//                reportEntry.setEmployeeName(centralPoint.getUsersMap().get(worklog.getAuthor()).getDisplayName());
//                reportEntry.setEmployeeUserName(worklog.getAuthor());

                //Adding Jira issue to the cache
//                if (!centralPoint.getIssueCache().containsKey(worklog.getIssueid())) {
//                    fillJiraIssueCache(worklog);
//                }
//
//                Jiraissue currentIssue=centralPoint.getIssueCache().get(worklog.getIssueid());

//                reportEntry.setEmployeeUserName(currentIssue.getAssignee());
//                for (EmploymentInterval employmentInterval: currentIssue.getEmploymentIntervals()) {
//                    if ((worklog.getStartdate().after(employmentInterval.getStart()) || worklog.getStartdate().equals(employmentInterval.getStart()))
//                            && (worklog.getStartdate().before(employmentInterval.getEnd()) || worklog.getStartdate().equals(employmentInterval.getEnd()))) {
//                        reportEntry.setEmployeeUserName(employmentInterval.getEmployeeName());
////                        for (CwdUser cwdUser: centralPoint.getUsersList()) {
////                            if (cwdUser.getUserName().equals(employmentInterval.getEmployeeName())) {
////                                reportEntry.setEmployeeName(cwdUser.getDisplayName())
////                            }
////                        }
//                        reportEntry.setEmployeeName(centralPoint.getUsersMap().get(employmentInterval.getEmployeeName()).getDisplayName());
//                        break;
//                    }
//                }
                
//                reportEntry.setEmployeeName(centralPoint.getUsersMap().get(currentIssue.getAssignee()).getDisplayName());
                
                
//                System.out.println(currentIssue.getPkey()+" "+trackedEmployee);
                reportEntry.setEmployeeId(centralPoint.getUsersMap().get(trackedEmployee).getId());
                reportEntry.setEmployeeUserName(trackedEmployee);
//                reportEntry.setEmployeeName(centralPoint.getUsersMap().get(trackedEmployee).getDisplayName());
                reportEntry.setEmployeeName(employeeDisplayName);
                
                reportEntry.setRole(currentIssue.getCustomFields().get("Роль"));
                reportEntry.setPlatform(currentIssue.getCustomFields().get("Платформа"));
                reportEntry.setDevForm(currentIssue.getCustomFields().get("Вид разработки"));
                reportEntry.setDevType(currentIssue.getCustomFields().get("Тип разработки"));
                reportEntry.setDevHMA(currentIssue.getCustomFields().get("Разрабатываемый проект (НМА)"));
                reportEntry.setOrganization(currentIssue.getCustomFields().get("Организация"));

                reportEntry.setProjectName(currentIssue.getPkey()+" "+currentIssue.getSummary());
                reportEntry.setStartReportPeriod(startPeriod);
                reportEntry.setEndReportPeriod(endPeriod);

                //Mock
//                reportEntry.setStartPlanned(worklog.getStartdate());
                
                //Start of work actual
                Query queryMisc=centralPoint.getEntityManager().createNamedQuery("OsHistorystep.findByStatusEntryId");
                queryMisc.setParameter("entryId", currentIssue.getWorkflowId());
                queryMisc.setParameter("stepIds", Arrays.asList(3));
                queryMisc.setMaxResults(1);
                List<OsHistorystep> trackingIssueList=queryMisc.getResultList();
                if (!trackingIssueList.isEmpty()) {
                    reportEntry.setStartActual(trackingIssueList.get(0).getStartDate());
//                    trackingIssueList.get(0).getCaller();
                } else {
//                    System.out.println(currentIssue.getPkey()+" under watch");
                    Query queryMiscOtherwise=centralPoint.getEntityManager().createNamedQuery("OsCurrentstep.findByEntryIdStepId");
                    queryMiscOtherwise.setParameter("entryId", currentIssue.getWorkflowId());
                    queryMiscOtherwise.setParameter("stepIds", Arrays.asList(3));
                    
                    List<OsCurrentstep> currentIssueStatusList=queryMiscOtherwise.getResultList();
                    if (!currentIssueStatusList.isEmpty()) {
                        reportEntry.setStartActual(currentIssueStatusList.get(0).getStartDate());
//                        System.out.println(currentIssue.getPkey()+" resolved");
                    }
                }

                //Endt of work actual
                List<Integer> closedIssueStatus=new ArrayList<>();
                closedIssueStatus.add(5); closedIssueStatus.add(6);
                queryMisc=centralPoint.getEntityManager().createNamedQuery("OsCurrentstep.findByEntryIdStepId");
                queryMisc.setParameter("entryId", currentIssue.getWorkflowId());
                queryMisc.setParameter("stepIds", closedIssueStatus);
                List<OsCurrentstep> currentIssueStatusList=queryMisc.getResultList();
                for (OsCurrentstep currentStatus: currentIssueStatusList) {
                    reportEntry.setEndActual(currentStatus.getStartDate());
                }

                //End of work planned
                reportEntry.setEndPlanned(currentIssue.getDuedate());
                reportEntry.setLaborExpendituresPlanned(currentIssue.getTimeoriginalestimate());

                //Work area a.k.a. Jira Project
                reportEntry.setWorkArea(centralPoint.getProjectsMap().get(currentIssue.getProject()).getPname());
                for (String devGroupName: centralPoint.getDevGroupsList()) {
                    if (centralPoint.getDevGroupsMap().get(devGroupName).getJiraProjectsSet().contains(reportEntry.getWorkArea())) {
                        reportEntry.setDevGroup(devGroupName);
                        break;
                    }
                }

                reportList.add(reportEntry);
            }
        }
    }
    
    private String getUserFromTrackLog(Jiraissue jiraIssue, Worklog worklog) {
        if (jiraIssue.getEmploymentIntervals().size()==1) {
            return jiraIssue.getEmploymentIntervals().get(0).getEmployeeName();
        }
        for (EmploymentInterval employmentInterval: jiraIssue.getEmploymentIntervals()) {
            if ((worklog.getStartdate().after(employmentInterval.getStart()) || worklog.getStartdate().equals(employmentInterval.getStart()))
                    && (worklog.getStartdate().before(employmentInterval.getEnd()) || worklog.getStartdate().equals(employmentInterval.getEnd()))) {
                return employmentInterval.getEmployeeName();
            }
        }
//        return null;
        return jiraIssue.getEmploymentIntervals().get(0).getEmployeeName();
    }
    
    private String getUserFromTrackLogSup(JiraissueSup jiraIssueSup, WorklogSup worklogSup) {
        if (jiraIssueSup.getEmploymentIntervals().size()==1) {
            return jiraIssueSup.getEmploymentIntervals().get(0).getEmployeeName();
        }
        for (EmploymentInterval employmentInterval: jiraIssueSup.getEmploymentIntervals()) {
            if ((worklogSup.getStartdate().after(employmentInterval.getStart()) || worklogSup.getStartdate().equals(employmentInterval.getStart()))
                    && (worklogSup.getStartdate().before(employmentInterval.getEnd()) || worklogSup.getStartdate().equals(employmentInterval.getEnd()))) {
                return employmentInterval.getEmployeeName();
            }
        }
//        return null;
        return jiraIssueSup.getEmploymentIntervals().get(0).getEmployeeName();
    }
    
    private void fillJiraIssueCache(Worklog worklog) {
        Jiraissue jiraissue=centralPoint.getEntityManager().find(Jiraissue.class, worklog.getIssueid());
        centralPoint.getEntityManager().detach(jiraissue);
        
        Query queryCustomFieldValue=centralPoint.getEntityManager().createNamedQuery("Customfieldvalue.findByIssue").setParameter("issue", jiraissue.getId());
        List<Customfieldvalue> customFieldRelation=queryCustomFieldValue.getResultList();
        for (Customfieldvalue customFieldValue: customFieldRelation) {
            try {
                if ((customFieldValue.getCustomfield().equals(11900l)) && (customFieldValue.getParentkey()==null)) {
                    jiraissue.getCustomFields().put("Организация", 
                        centralPoint.getCustomFieldOptionsMap().get(Long.parseLong(customFieldValue.getStringvalue())).getCustomvalue());
                } else if ((customFieldValue.getCustomfield().equals(11900l)) && (customFieldValue.getParentkey()!=null)) {
                    jiraissue.getCustomFields().put(centralPoint.getCustomFieldsMap().get(customFieldValue.getCustomfield()).getCfname(), 
                        centralPoint.getCustomFieldOptionsMap().get(Long.parseLong(customFieldValue.getStringvalue())).getCustomvalue());
                } else {
                
                }
            } catch (NumberFormatException ex) {
                jiraissue.getCustomFields().put(centralPoint.getCustomFieldsMap().get(customFieldValue.getCustomfield()).getCfname(), 
                        customFieldValue.getStringvalue());
            }
        }
        
        //Responsibility scopes
        String teamLead=centralPoint.getProjectsMap().get(jiraissue.getProject()).getLead();
        jiraissue.getEmploymentIntervals().add(new EmploymentInterval(teamLead, jiraissue.getCreated(), null));
        jiraissue.getCreated().setSeconds(0);
        
        int index=0;
        Query queryChangeGroup=centralPoint.getEntityManager().createNamedQuery("Changegroup.findByIssueid");
        queryChangeGroup.setParameter("issueid", jiraissue.getId());
        List<Changegroup> changeGroupList=queryChangeGroup.getResultList();
        for (Changegroup changeGroupItem: changeGroupList) {
            Long changeGroupdId=changeGroupItem.getId();
            Query queryChangeItems=centralPoint.getEntityManager().createNamedQuery("Changeitem.findByGroupidField");
            queryChangeItems.setParameter("groupid", changeGroupdId);
            queryChangeItems.setParameter("field", "assignee");
            List<Changeitem> changeItemsList=queryChangeItems.getResultList();
            
            for (Changeitem changeItem: changeItemsList) {
                if (changeItem.getOldvalue()!=null) {
                    jiraissue.getEmploymentIntervals().get(index).setEmployeeName(changeItem.getOldvalue());
                } else {
                    jiraissue.getEmploymentIntervals().get(index).setEmployeeName(teamLead);
                }
                jiraissue.getEmploymentIntervals().get(index).setEnd(changeGroupItem.getCreated());
                index++;
                jiraissue.getEmploymentIntervals().add(new EmploymentInterval(changeItem.getNewvalue(), changeGroupItem.getCreated(), null));
            }
        }
        
        jiraissue.getEmploymentIntervals().get(jiraissue.getEmploymentIntervals().size()-1).setEnd(new Date());
        
        if (jiraissue.getEmploymentIntervals().size()==1) {
            EmploymentInterval employmeymentInterval=jiraissue.getEmploymentIntervals().get(0);
            employmeymentInterval.setEmployeeName(jiraissue.getAssignee());
            employmeymentInterval.setStart(jiraissue.getCreated());
        }
        
//        System.out.println(jiraissue.getPkey()+" "+worklog.getStartdate());
//        for (EmploymentInterval employmentInterval: jiraissue.getEmploymentIntervals()) {
//            System.out.println(employmentInterval.getEmployeeName()+" "+employmentInterval.getStart()+" "+employmentInterval.getEnd());
//        }
        
        centralPoint.getIssueCache().put(worklog.getIssueid(), jiraissue);
    }

    private void fillReportEntry(ReportEntry reportEntry, Worklog worklog) {
        reportEntry=new ReportEntry(worklog.getIssueid(), worklog.getAuthor(), worklog.getTimeworked());
        reportEntry.setEmployeeName(centralPoint.getUsersMap().get(worklog.getAuthor()).getDisplayName());
        reportEntry.setEmployeeId(centralPoint.getUsersMap().get(worklog.getAuthor()).getId());
        
        //Adding Jira issue to the cache
        if (!centralPoint.getIssueCache().containsKey(worklog.getIssueid())) {
            Jiraissue jiraissue=centralPoint.getEntityManager().find(Jiraissue.class, worklog.getIssueid());
            Query queryCustomFieldValue=centralPoint.getEntityManager().createNamedQuery("Customfieldvalue.findByIssue").setParameter("issue", jiraissue.getId());
            List<Customfieldvalue> customFieldRelation=queryCustomFieldValue.getResultList();
            for (Customfieldvalue customFieldValue: customFieldRelation) {
                try {
                    if ((customFieldValue.getCustomfield().equals(11900l)) && (customFieldValue.getParentkey()==null)) {
                        jiraissue.getCustomFields().put("Организация", 
                            centralPoint.getCustomFieldOptionsMap().get(Long.parseLong(customFieldValue.getStringvalue())).getCustomvalue());
                    } else {
                        jiraissue.getCustomFields().put(centralPoint.getCustomFieldsMap().get(customFieldValue.getCustomfield()).getCfname(), 
                            centralPoint.getCustomFieldOptionsMap().get(Long.parseLong(customFieldValue.getStringvalue())).getCustomvalue());
                    }
                    
                } catch (NumberFormatException ex) {
                    jiraissue.getCustomFields().put(centralPoint.getCustomFieldsMap().get(customFieldValue.getCustomfield()).getCfname(), 
                            customFieldValue.getStringvalue());
                }
            }

            centralPoint.getIssueCache().put(worklog.getIssueid(), jiraissue);
        }
        
        Jiraissue currentIssue=centralPoint.getIssueCache().get(worklog.getIssueid());
        
        reportEntry.setRole(currentIssue.getCustomFields().get("Роль"));
        reportEntry.setPlatform(currentIssue.getCustomFields().get("Платформа"));
        reportEntry.setDevForm(currentIssue.getCustomFields().get("Вид разработки"));
        reportEntry.setDevType(currentIssue.getCustomFields().get("Тип разработки"));
        reportEntry.setDevHMA(currentIssue.getCustomFields().get("Разрабатываемый проект (НМА)"));
        reportEntry.setOrganization(currentIssue.getCustomFields().get("Организация"));
        
        reportEntry.setProjectName(currentIssue.getPkey()+" "+currentIssue.getSummary());
        reportEntry.setStartReportPeriod(startPeriod);
        reportEntry.setEndReportPeriod(endPeriod);
        
        //Start of work actual
        Query query=centralPoint.getEntityManager().createNamedQuery("OsHistorystep.findByStatusEntryId");
        query.setParameter("entryId", currentIssue.getWorkflowId());
        query.setParameter("stepId", 3);
        query.setMaxResults(1);
        List<OsHistorystep> trackingIssueList=query.getResultList();
        if (!trackingIssueList.isEmpty()) {
            reportEntry.setStartActual(trackingIssueList.get(0).getStartDate());
        }
        
        //Start of work actual
        List<Integer> closedIssueStatus=new ArrayList<>();
        closedIssueStatus.add(5); closedIssueStatus.add(6);
        query=centralPoint.getEntityManager().createNamedQuery("OsCurrentstep.findByEntryIdStepId");
        query.setParameter("entryId", currentIssue.getWorkflowId());
        query.setParameter("stepIds", closedIssueStatus);
        List<OsCurrentstep> currentIssueStatusList=query.getResultList();
        for (OsCurrentstep currentStatus: currentIssueStatusList) {
            reportEntry.setEndActual(currentStatus.getStartDate());
        }
        
        //End of work planned
        reportEntry.setEndPlanned(currentIssue.getDuedate());
        reportEntry.setLaborExpendituresPlanned(currentIssue.getTimeoriginalestimate());
        
        //Work area a.k.a. Jira Project
        reportEntry.setWorkArea(centralPoint.getProjectsMap().get(currentIssue.getProject()).getPname());
        
        reportList.add(reportEntry);
    }
    
    private void fillReportEntrySup(ReportEntry reportEntry, WorklogSup worklogSup) {
        reportEntry=new ReportEntry(worklogSup.getIssueid(), worklogSup.getAuthor(), worklogSup.getTimeworked());
        reportEntry.setEmployeeName(centralPoint.getUsersMapSup().get(worklogSup.getAuthor()).getDisplayName());
        reportEntry.setEmployeeId(centralPoint.getUsersMapSup().get(worklogSup.getAuthor()).getId());
        
        //Adding Jira issue to the cache
        if (!centralPoint.getIssueCacheSup().containsKey(worklogSup.getIssueid())) {
            JiraissueSup jiraissueSup=centralPoint.getEntityManagerSup().find(JiraissueSup.class, worklogSup.getIssueid());
//            Query queryCustomFieldValue=centralPoint.getEntityManagerSup().createNamedQuery("CustomfieldvalueSup.findByIssue").setParameter("issue", jiraissueSup.getId());
//            List<Customfieldvalue> customFieldRelation=queryCustomFieldValue.getResultList();
//            for (Customfieldvalue customFieldValue: customFieldRelation) {
//                try {
//                    if ((customFieldValue.getCustomfield().equals(11900l)) && (customFieldValue.getParentkey()==null)) {
//                        jiraissue.getCustomFields().put("Организация", 
//                            centralPoint.getCustomFieldOptionsMap().get(Long.parseLong(customFieldValue.getStringvalue())).getCustomvalue());
//                    } else {
//                        jiraissue.getCustomFields().put(centralPoint.getCustomFieldsMap().get(customFieldValue.getCustomfield()).getCfname(), 
//                            centralPoint.getCustomFieldOptionsMap().get(Long.parseLong(customFieldValue.getStringvalue())).getCustomvalue());
//                    }
//                    
//                } catch (NumberFormatException ex) {
//                    jiraissue.getCustomFields().put(centralPoint.getCustomFieldsMap().get(customFieldValue.getCustomfield()).getCfname(), 
//                            customFieldValue.getStringvalue());
//                }
//            }

            centralPoint.getIssueCacheSup().put(worklogSup.getIssueid(), jiraissueSup);
        }
        
        JiraissueSup currentIssue=centralPoint.getIssueCacheSup().get(worklogSup.getIssueid());
        
//        reportEntry.setRole(currentIssue.getCustomFields().get("Роль"));
//        reportEntry.setPlatform(currentIssue.getCustomFields().get("Платформа"));
//        reportEntry.setDevForm(currentIssue.getCustomFields().get("Вид разработки"));
//        reportEntry.setDevType(currentIssue.getCustomFields().get("Тип разработки"));
//        reportEntry.setDevHMA(currentIssue.getCustomFields().get("Разрабатываемый проект (НМА)"));
//        reportEntry.setOrganization(currentIssue.getCustomFields().get("Организация"));
        
        reportEntry.setProjectName(currentIssue.getPkey()+" "+currentIssue.getSummary());
        reportEntry.setStartReportPeriod(startPeriod);
        reportEntry.setEndReportPeriod(endPeriod);
        
        //Start of work actual
        Query query=centralPoint.getEntityManagerSup().createNamedQuery("OsHistorystepSup.findByStatusEntryId");
        query.setParameter("entryId", currentIssue.getWorkflowId());
        query.setParameter("stepId", 3);
        query.setMaxResults(1);
        List<OsHistorystepSup> trackingIssueListSup=query.getResultList();
        if (!trackingIssueListSup.isEmpty()) {
            reportEntry.setStartActual(trackingIssueListSup.get(0).getStartDate());
        }
        
        //Start of work actual
        List<Integer> closedIssueStatus=new ArrayList<>();
        closedIssueStatus.add(5); closedIssueStatus.add(6);
        query=centralPoint.getEntityManagerSup().createNamedQuery("OsCurrentstepSup.findByEntryIdStepId");
        query.setParameter("entryId", currentIssue.getWorkflowId());
        query.setParameter("stepIds", closedIssueStatus);
        List<OsCurrentstepSup> currentIssueStatusListSup=query.getResultList();
        for (OsCurrentstepSup currentStatusSup: currentIssueStatusListSup) {
            reportEntry.setEndActual(currentStatusSup.getStartDate());
        }
        
        //End of work planned
        reportEntry.setEndPlanned(currentIssue.getDuedate());
        reportEntry.setLaborExpendituresPlanned(currentIssue.getTimeoriginalestimate());
        
        //Work area a.k.a. Jira Project
        reportEntry.setWorkArea(centralPoint.getProjectsMapSup().get(currentIssue.getProject()).getPname());
        
        reportList.add(reportEntry);
    }

     /**
     * Filters users for user select combobox
     * @throws IOException 
     */
    public void filterUsers() throws IOException {
        Set<String> filteredUserSet=new HashSet<>();
        
        filteredUserList.clear();
        filteredUserMap.clear();
        selectedUsersList=null;
        
        if (filterUserPattern!=null && !filterUserPattern.isEmpty()) {
            Pattern pattern = Pattern.compile("(?i)"+filterUserPattern+".*");
            
            //Rambler Jira
            for (CwdUser cwdUser: centralPoint.getUsersList()) {
                Matcher matcher = pattern.matcher(cwdUser.getDisplayName());
                if (matcher.matches()) {
                    filteredUserSet.add(cwdUser.getDisplayName());
                    filteredUserMap.put(cwdUser.getDisplayName(), cwdUser.getUserName());
                }
            }
            
            //SUP Jira
            for (CwdUserSup cwdUserSup: centralPoint.getUsersListSup()) {
                Matcher matcher = pattern.matcher(cwdUserSup.getDisplayName());
                if (matcher.matches()) {
                    filteredUserSet.add(cwdUserSup.getDisplayName());
                    filteredUserMap.put(cwdUserSup.getDisplayName(), cwdUserSup.getUserName());
                }
            }
            
            filteredUserList.addAll(filteredUserSet);
            Collections.sort(filteredUserList);
        } 
        
        
    }
    
    public void clearControls() {
        filteredUserList.clear();
        filteredUserMap.clear();
        selectedUsersList=null;
        selectedWorkAreaList.clear();
        selectedOrganizationsList=null;
        selectedProjectsHMAList=null;
        selectedDevGroups=null;
        filterUserPattern=null;
        
        startPeriod=ToolBox.getFirstDateOfCurrentMonth();
        endPeriod=ToolBox.getLastDateOfCurrentMonth();
        
        reportList.clear();
        centralPoint.getIssueCache().clear();
        detailedReportByUsers.clear();
        detailedReportByProjects.clear();
        
        isFullReportVisible=false; 
        isDetailedByUsersReportVisible=false;
        isDetailedByProjectsReportVisible=false;
        isSortByUserAsc=false;
        isSortByTaskNameAsc=false;
        isSortByWorkAreaAsc=false;
        
        chosenUsers=null;
        chosenUsersFullList.clear();
        chosenUsersFullSet.clear();
    }
    
    private String convertDate(Date date) {
        DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
        
        if (date!=null) {
            return df.format(date);
        } else {
            return "";
        }
    }
    
    private String cauterize(String rawStr) {
        if (rawStr==null) {
            return "";
        } else {
            return rawStr.replaceAll("\"", "'");
        }
    }
    
    private String dotCommaReplacer(String rawStr) {
        if (rawStr==null) {
            return "";
        } else {
            return rawStr.replaceAll("\\.", ",");
        }
    }
    
    private String exportCSV() {
        String header="\"Группа разработки\",\"Рабочая область\",\"Начало периода\",\"Конец периода\",\"Вид разработки\",\"Тип разработки\",\"Наименование задачи\",\"Для кого делается проект\",\"Разрабатываемый проект (НМА)\",\"Платформа разработки\",\"ID сотрудника\",\"ФИО сотрудника\",\"Роль\",\"Начало, план\",\"Начало, факт\",\"Окончание, план\",\"Окончание, факт\",\"Трудозатраты, план\",\"Трудозатраты, факт\"\n";
        String content=header; String delimiter="\",\"";
        
        for (ReportEntry reportEntry: reportList) {
            content+="\""+cauterize(reportEntry.getDevGroup())+delimiter+cauterize(reportEntry.getWorkArea())+delimiter+convertDate(reportEntry.getStartReportPeriod())
                    +delimiter+convertDate(reportEntry.getEndReportPeriod())+delimiter+cauterize(reportEntry.getDevForm())+delimiter+cauterize(reportEntry.getDevType())
                    +delimiter+cauterize(reportEntry.getProjectName())+delimiter+cauterize(reportEntry.getOrganization())+delimiter+cauterize(reportEntry.getDevHMA())
                    +delimiter+cauterize(reportEntry.getPlatform())+delimiter+reportEntry.getEmployeeId()+delimiter+cauterize(reportEntry.getEmployeeName())
                    +delimiter+cauterize(reportEntry.getRole())+delimiter+convertDate(reportEntry.getStartPlanned())+delimiter+convertDate(reportEntry.getStartActual())
                    +delimiter+convertDate(reportEntry.getEndPlanned())+delimiter+convertDate(reportEntry.getEndActual())
                    +delimiter+dotCommaReplacer(((float) reportEntry.getLaborExpendituresPlanned())/3600+delimiter)+dotCommaReplacer(((float) reportEntry.getLaborExpendituresActual())/3600+"\"\n");
        }
        
        return content;
    }
    
    private byte[] convertStringToBytes(String text) {
        try {
            return text.getBytes("Cp1251");
        } catch (UnsupportedEncodingException ex) {
            ex.printStackTrace();
            return text.getBytes();
        }
    }
    
    private void download(byte[] bytes) throws IOException {
        FacesContext fc = FacesContext.getCurrentInstance();
        ExternalContext ec = fc.getExternalContext();
        String contentType="application/octet-stream";
        String fileName="DevelopmentReport.csv";
        int contentLength = bytes.length; 

        ec.responseReset(); // Some JSF component library or some Filter might have set some headers in the buffer beforehand. We want to get rid of them, else it may collide.
        ec.setResponseContentType(contentType); // Check http://www.iana.org/assignments/media-types for all types. Use if necessary ExternalContext#getMimeType() for auto-detection based on filename.
        ec.setResponseContentLength(contentLength); // Set it with the file size. This header is optional. It will work if it's omitted, but the download progress will be unknown.
        ec.setResponseHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\""); // The Save As popup magic is done here. You can give it any file name you want, this only won't work in MSIE, it will use current request URL as file name instead.
        OutputStream output = ec.getResponseOutputStream();
        output.write(bytes, 0, contentLength);

        fc.responseComplete(); // Important! Otherwise JSF will attempt to render the response which obviously will fail since it's already written with a file and closed.
    }    
    
    public void downloadCSV() throws IOException {
        if(!reportList.isEmpty()) {
            download(convertStringToBytes(exportCSV()));
        }
    }
    
    public void sortByUser() {
        if (reportList.size()>1) {
            isSortByUserAsc=!isSortByUserAsc;

            for (int i=0; i<reportList.size()-1; i++) {
                for (int j=i+1; j<reportList.size(); j++) {
                    if (isSortByUserAsc==(reportList.get(i).getEmployeeName().compareTo(reportList.get(j).getEmployeeName())>0)) {
                        Collections.swap(reportList, i, j);
                    }
                }
            }
        }
    }
    
    public void sortByTaskName() {
        if (reportList.size()>1) {
            isSortByTaskNameAsc=!isSortByTaskNameAsc;

            for (int i=0; i<reportList.size()-1; i++) {
                for (int j=i+1; j<reportList.size(); j++) {
                    if (isSortByTaskNameAsc==(reportList.get(i).getProjectName().compareTo(reportList.get(j).getProjectName())>0)) {
                        Collections.swap(reportList, i, j);
                    }
                }
            }
        }
    }
    
    public void sortByWorkArea() {
        if (reportList.size()>1) {
            isSortByWorkAreaAsc=!isSortByWorkAreaAsc;

            for (int i=0; i<reportList.size()-1; i++) {
                for (int j=i+1; j<reportList.size(); j++) {
                    if (isSortByWorkAreaAsc==(reportList.get(i).getWorkArea().compareTo(reportList.get(j).getWorkArea())>0)) {
                        Collections.swap(reportList, i, j);
                    }
                }
            }
        }
    }
    
    public void sortByOrganization() {
        if (reportList.size()>1) {
            isSortByOrganizationAsc=!isSortByOrganizationAsc;

            for (int i=0; i<reportList.size()-1; i++) {
                for (int j=i+1; j<reportList.size(); j++) {
                    if (isSortByOrganizationAsc==(reportList.get(i).getOrganization().compareTo(reportList.get(j).getOrganization())>0)) {
                        Collections.swap(reportList, i, j);
                    }
                }
            }
        }
    }
    
    public void sortByDevHMA() {
        if (reportList.size()>1) {
            isSortByDevHMAAsc=!isSortByDevHMAAsc;

            for (int i=0; i<reportList.size()-1; i++) {
                for (int j=i+1; j<reportList.size(); j++) {
                    if (isSortByDevHMAAsc==(reportList.get(i).getDevHMA().compareTo(reportList.get(j).getDevHMA())>0)) {
                        Collections.swap(reportList, i, j);
                    }
                }
            }
        }
    }
    
    public void sortByPlatform() {
        if (reportList.size()>1) {
            isSortByPlatformAsc=!isSortByPlatformAsc;

            for (int i=0; i<reportList.size()-1; i++) {
                for (int j=i+1; j<reportList.size(); j++) {
                    if (isSortByPlatformAsc==(reportList.get(i).getPlatform().compareTo(reportList.get(j).getPlatform())>0)) {
                        Collections.swap(reportList, i, j);
                    }
                }
            }
        }
    }
    
    public void sortByRole() {
        if (reportList.size()>1) {
            isSortByRoleAsc=!isSortByRoleAsc;

            for (int i=0; i<reportList.size()-1; i++) {
                for (int j=i+1; j<reportList.size(); j++) {
                    if (isSortByRoleAsc==(reportList.get(i).getRole().compareTo(reportList.get(j).getRole())>0)) {
                        Collections.swap(reportList, i, j);
                    }
                }
            }
        }
    }
    
    public void sortByDevType() {
        if (reportList.size()>1) {
            isSortByDevTypeAsc=!isSortByDevTypeAsc;

            for (int i=0; i<reportList.size()-1; i++) {
                for (int j=i+1; j<reportList.size(); j++) {
                    if (isSortByDevTypeAsc==(reportList.get(i).getDevType().compareTo(reportList.get(j).getDevType())>0)) {
                        Collections.swap(reportList, i, j);
                    }
                }
            }
        }
    }
    
    public void sortByDevForm() {
        if (reportList.size()>1) {
            isSortByDevFormAsc=!isSortByDevFormAsc;

            for (int i=0; i<reportList.size()-1; i++) {
                for (int j=i+1; j<reportList.size(); j++) {
                    if (isSortByDevFormAsc==(reportList.get(i).getDevForm().compareTo(reportList.get(j).getDevForm())>0)) {
                        Collections.swap(reportList, i, j);
                    }
                }
            }
        }
    }
    
    public void sortByDevGroup() {
        if (reportList.size()>1) {
            isSortByDevGroupAsc=!isSortByDevGroupAsc;
        
            for (int i=0; i<reportList.size()-1; i++) {
                for (int j=i+1; j<reportList.size(); j++) {
                    if (isSortByDevGroupAsc==(reportList.get(i).getDevGroup().compareTo(reportList.get(j).getDevGroup())>0)) {
                        Collections.swap(reportList, i, j);
                    }
                }
            }
        }
    }
    
    public void addUsers() {
        if (chosenUsers!=null && !chosenUsers.isEmpty()) {
            chosenUsersFullSet.addAll(chosenUsers);
            
            chosenUsersFullList.clear();
            chosenUsersFullList.addAll(chosenUsersFullSet);
        
            Collections.sort(chosenUsersFullList);
        }
    }
    
    public void removeUsers() {
        if (selectedUsersList!=null && !selectedUsersList.isEmpty()) {
            chosenUsersFullSet.removeAll(selectedUsersList);
            
            chosenUsersFullList.clear();
            chosenUsersFullList.addAll(chosenUsersFullSet);

            Collections.sort(chosenUsersFullList);
        }
    }
    
    public void clearUsers() {
        chosenUsersFullList.clear();
        chosenUsersFullSet.clear();
        selectedUsersList=null;
    }
    
    @PostConstruct
    public void postConstruct() throws RuntimeException {
        
    }
}
