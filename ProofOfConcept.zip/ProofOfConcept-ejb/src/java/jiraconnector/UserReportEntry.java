/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author a.shalin
 */
public class UserReportEntry implements Serializable, Comparable<UserReportEntry>{
    private String devGroup, workArea, devForm, devType, projectName, userDisplayName;
    private String organization, devHMA, role, platform;
    private Date startReportPeriod, endReportPeriod;
    private long laborExpendure, laborExpendurePlanned;
    private long jiraIssueId;

    public String getDevGroup() {
        return devGroup;
    }

    public void setDevGroup(String devGroup) {
        this.devGroup = devGroup;
    }

    public String getWorkArea() {
        return workArea;
    }

    public void setWorkArea(String workArea) {
        this.workArea = workArea;
    }

    public String getDevForm() {
        return devForm;
    }

    public void setDevForm(String devForm) {
        this.devForm = devForm;
    }

    public String getDevType() {
        return devType;
    }

    public void setDevType(String devType) {
        this.devType = devType;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public Date getStartReportPeriod() {
        return startReportPeriod;
    }

    public void setStartReportPeriod(Date startReportPeriod) {
        this.startReportPeriod = startReportPeriod;
    }

    public Date getEndReportPeriod() {
        return endReportPeriod;
    }

    public void setEndReportPeriod(Date endReportPeriod) {
        this.endReportPeriod = endReportPeriod;
    }

    public long getLaborExpendure() {
        return laborExpendure;
    }

    public void setLaborExpendure(long laborExpendure) {
        this.laborExpendure = laborExpendure;
    }

    public String getUserDisplayName() {
        return userDisplayName;
    }

    public void setUserDisplayName(String userDisplayName) {
        this.userDisplayName = userDisplayName;
    }

    public long getJiraIssueId() {
        return jiraIssueId;
    }

    public void setJiraIssueId(long jiraIssueId) {
        this.jiraIssueId = jiraIssueId;
    }

    public String getOrganization() {
        return organization;
    }

    public String getDevHMA() {
        return devHMA;
    }

    public void setDevHMA(String devHMA) {
        this.devHMA = devHMA;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public long getLaborExpendurePlanned() {
        return laborExpendurePlanned;
    }

    public void setLaborExpendurePlanned(long laborExpendurePlanned) {
        this.laborExpendurePlanned = laborExpendurePlanned;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }
    
    public UserReportEntry() {
        laborExpendure=0;
    }

    @Override
    public int compareTo(UserReportEntry userReportEntry) {
        return this.projectName.compareTo(userReportEntry.getProjectName());
    }
}
