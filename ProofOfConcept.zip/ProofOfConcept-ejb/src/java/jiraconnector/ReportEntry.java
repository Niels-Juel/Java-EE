/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector;

import java.util.Date;
/**
 *
 * @author a.shalin
 */
public class ReportEntry {
    private String devGroup;
    private Date startReportPeriod, endReportPeriod;
    private String devForm, devType;
    private String projectName, organization;
    private String platform, devHMA;
    private long employeeId, jiraIssueId;
    private String employeeName, employeeUserName, role;
    private Date startPlanned, endPlanned;
    private Date startActual, endActual;
    private long laborExpendituresPlanned, laborExpendituresActual;
    private String workArea;

    public String getWorkArea() {
        return workArea;
    }

    public void setWorkArea(String workArea) {
        this.workArea = workArea;
    }

    public String getDevGroup() {
        if (devGroup==null) {
            return "";
        } else {
            return devGroup;
        }
    }

    public void setDevGroup(String devGroup) {
        this.devGroup = devGroup;
    }

    public Date getStartReportPeriod() {
        return startReportPeriod;
    }

    public void setStartReportPeriod(Date startReportPeriod) {
        this.startReportPeriod = startReportPeriod;
    }

    public Date getEndReportPeriod() {
        return endReportPeriod;
    }

    public void setEndReportPeriod(Date endReportPeriod) {
        this.endReportPeriod = endReportPeriod;
    }

    public String getDevForm() {
        if  (devForm==null) {
            return "";
        } else {
            return devForm;
        }
    }

    public void setDevForm(String devForm) {
        this.devForm = devForm;
    }

    public String getDevType() {
        if (devType==null) {
            return "";
        } else {
            return devType;
        }
    }

    public void setDevType(String devType) {
        this.devType = devType;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getOrganization() {
        if (organization==null) {
            return "";
        } else {
            return organization;
        }
    }

    public void setOrganization(String Organization) {
        this.organization = Organization;
    }

    public String getPlatform() {
        if (this.platform==null) {
            return "";
        }   else {
            return platform;
        }
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getDevHMA() {
        if (devHMA==null) {
            return "";
        } else {
            return devHMA;
        }
    }

    public void setDevHMA(String devHMA) {
        this.devHMA = devHMA;
    }

    public long getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(long employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmployeeUserName() {
        return employeeUserName;
    }

    public void setEmployeeUserName(String employeeUserName) {
        this.employeeUserName = employeeUserName;
    }

    public String getRole() {
        if (role==null) {
            return "";
        } else {
            return role;
        }
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Date getStartPlanned() {
        return startPlanned;
    }

    public void setStartPlanned(Date startPlanned) {
        this.startPlanned = startPlanned;
    }

    public Date getEndPlanned() {
        return endPlanned;
    }

    public void setEndPlanned(Date endPlanned) {
        this.endPlanned = endPlanned;
    }

    public Date getStartActual() {
        return startActual;
    }

    public void setStartActual(Date startActual) {
        this.startActual = startActual;
    }

    public Date getEndActual() {
        return endActual;
    }

    public void setEndActual(Date endActual) {
        this.endActual = endActual;
    }

    public long getLaborExpendituresPlanned() {
        return laborExpendituresPlanned;
    }

    public void setLaborExpendituresPlanned(long laborExpendituresPlanned) {
        this.laborExpendituresPlanned = laborExpendituresPlanned;
    }

    public long getLaborExpendituresActual() {
        return laborExpendituresActual;
    }

    public void setLaborExpendituresActual(long laborExpendituresActual) {
        this.laborExpendituresActual = laborExpendituresActual;
    }

    public long getJiraIssueId() {
        return jiraIssueId;
    }

    public void setJiraIssueId(long jiraIssueId) {
        this.jiraIssueId = jiraIssueId;
    }
    
    public ReportEntry() {

    }
    
    public ReportEntry(long jiraIssueId, String employeeUserName, long laborExpendituresActual) {
        this.jiraIssueId=jiraIssueId;
        this.employeeUserName=employeeUserName;
        this.laborExpendituresActual=laborExpendituresActual;
        laborExpendituresPlanned=0;
    }
}
