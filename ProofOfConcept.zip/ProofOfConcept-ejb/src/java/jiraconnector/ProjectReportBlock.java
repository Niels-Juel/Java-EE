/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author a.shalin
 */
public class ProjectReportBlock implements Serializable, Comparable<ProjectReportBlock>{
    private String projectName;
    private long laborExpenditures, laborExpendituresPlanned;
    private final List<ProjectReportEntry> projectReportEntries;

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public long getLaborExpenditures() {
        return laborExpenditures;
    }

    public void setLaborExpenditures(long laborExpenditures) {
        this.laborExpenditures = laborExpenditures;
    }

    public long getLaborExpendituresPlanned() {
        return laborExpendituresPlanned;
    }

    public void setLaborExpendituresPlanned(long laborExpendituresPlanned) {
        this.laborExpendituresPlanned = laborExpendituresPlanned;
    }

    public List<ProjectReportEntry> getProjectReportEntries() {
        return projectReportEntries;
    }
    
    public ProjectReportBlock() {
        this.laborExpenditures=0;
        this.laborExpendituresPlanned=0;
        projectReportEntries=new ArrayList<>();
    }

    @Override
    public int compareTo(ProjectReportBlock projectReportBlock) {
        return this.getProjectName().compareTo(projectReportBlock.getProjectName());
    }
}
