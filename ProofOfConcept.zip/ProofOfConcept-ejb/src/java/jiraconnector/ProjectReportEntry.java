/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector;

import java.io.Serializable;

/**
 *
 * @author a.shalin
 */
public class ProjectReportEntry implements Serializable, Comparable<ProjectReportEntry> {
    private String taskName, workArea, employeeName, platform, role, organization, devType, devForm;
    private long laborExpenditures, laborExpendituresPlanned;

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getWorkArea() {
        return workArea;
    }

    public void setWorkArea(String workArea) {
        this.workArea = workArea;
    }

    public long getLaborExpenditures() {
        return laborExpenditures;
    }

    public void setLaborExpenditures(long laborExpenditures) {
        this.laborExpenditures = laborExpenditures;
    }

    public long getLaborExpendituresPlanned() {
        return laborExpendituresPlanned;
    }

    public void setLaborExpendituresPlanned(long laborExpendituresPlanned) {
        this.laborExpendituresPlanned = laborExpendituresPlanned;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public String getDevType() {
        return devType;
    }

    public void setDevType(String devType) {
        this.devType = devType;
    }

    public String getDevForm() {
        return devForm;
    }

    public void setDevForm(String devForm) {
        this.devForm = devForm;
    }
    
    public ProjectReportEntry() {
        this.laborExpenditures=0;
        this.laborExpendituresPlanned=0;
    }

    @Override
    public int compareTo(ProjectReportEntry projectReportEntry) {
        return this.employeeName.compareTo(projectReportEntry.getEmployeeName());
    }
}
