/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 *
 * @author a.shalin
 */
public class ToolBox {
    public static Date getFirstDateOfCurrentMonth() {
        Calendar cal=Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH,Calendar.getInstance().getActualMinimum(Calendar.DAY_OF_MONTH));
//        cal.set(Calendar.HOUR_OF_DAY,Calendar.getInstance().getActualMinimum(Calendar.HOUR_OF_DAY));
//        cal.set(Calendar.HOUR_OF_DAY,1);
        return cal.getTime();
    }
    
    public static Date getLastDateOfCurrentMonth() {
        Calendar cal=Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH,Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH));
//        cal.set(Calendar.HOUR_OF_DAY,Calendar.getInstance().getActualMaximum(Calendar.HOUR_OF_DAY));
//        cal.set(Calendar.HOUR_OF_DAY,23);
        return cal.getTime();
    }

    public static TimeZone getTimeZone() {
        return TimeZone.getDefault();
    }
}
