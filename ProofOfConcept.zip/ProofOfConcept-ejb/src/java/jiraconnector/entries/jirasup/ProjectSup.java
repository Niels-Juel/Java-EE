/*
 * To change this license header, choose License Headers in ProjectSup Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector.entries.jirasup;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "project")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ProjectSup.findAll", query = "SELECT p FROM ProjectSup p ORDER BY p.pname"),
    @NamedQuery(name = "ProjectSup.findById", query = "SELECT p FROM ProjectSup p WHERE p.id = :id"),
    @NamedQuery(name = "ProjectSup.findByPname", query = "SELECT p FROM ProjectSup p WHERE p.pname = :pname"),
    @NamedQuery(name = "ProjectSup.findByUrl", query = "SELECT p FROM ProjectSup p WHERE p.url = :url"),
    @NamedQuery(name = "ProjectSup.findByLead", query = "SELECT p FROM ProjectSup p WHERE p.lead = :lead"),
    @NamedQuery(name = "ProjectSup.findByPkey", query = "SELECT p FROM ProjectSup p WHERE p.pkey = :pkey"),
    @NamedQuery(name = "ProjectSup.findByPcounter", query = "SELECT p FROM ProjectSup p WHERE p.pcounter = :pcounter"),
    @NamedQuery(name = "ProjectSup.findByAssigneetype", query = "SELECT p FROM ProjectSup p WHERE p.assigneetype = :assigneetype"),
    @NamedQuery(name = "ProjectSup.findByAvatar", query = "SELECT p FROM ProjectSup p WHERE p.avatar = :avatar")})
public class ProjectSup implements Serializable, Comparable<ProjectSup> {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Size(max = 255)
    @Column(name = "pname")
    private String pname;
    @Size(max = 255)
    @Column(name = "URL")
    private String url;
    @Size(max = 255)
    @Column(name = "LEAD")
    private String lead;
    @Lob
    @Size(max = 65535)
    @Column(name = "DESCRIPTION")
    private String description;
    @Size(max = 255)
    @Column(name = "pkey")
    private String pkey;
    @Column(name = "pcounter")
    private Long pcounter;
    @Column(name = "ASSIGNEETYPE")
    private Long assigneetype;
    @Column(name = "AVATAR")
    private Long avatar;

    public ProjectSup() {
    }

    public ProjectSup(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getLead() {
        return lead;
    }

    public void setLead(String lead) {
        this.lead = lead;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPkey() {
        return pkey;
    }

    public void setPkey(String pkey) {
        this.pkey = pkey;
    }

    public Long getPcounter() {
        return pcounter;
    }

    public void setPcounter(Long pcounter) {
        this.pcounter = pcounter;
    }

    public Long getAssigneetype() {
        return assigneetype;
    }

    public void setAssigneetype(Long assigneetype) {
        this.assigneetype = assigneetype;
    }

    public Long getAvatar() {
        return avatar;
    }

    public void setAvatar(Long avatar) {
        this.avatar = avatar;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ProjectSup)) {
            return false;
        }
        ProjectSup other = (ProjectSup) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return pname;
    }
    
    @Override
    public int compareTo(ProjectSup projectSup) {
        return this.pname.compareTo(projectSup.getPname());
    }
}
