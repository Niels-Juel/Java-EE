/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector.entries.jirasup;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "customfieldvalue")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CustomfieldvalueSup.findAll", query = "SELECT c FROM CustomfieldvalueSup c"),
    @NamedQuery(name = "CustomfieldvalueSup.findById", query = "SELECT c FROM CustomfieldvalueSup c WHERE c.id = :id"),
    @NamedQuery(name = "CustomfieldvalueSup.findByIssue", query = "SELECT c FROM CustomfieldvalueSup c WHERE c.issue = :issue AND c.stringvalue IS NOT NULL"),
    @NamedQuery(name = "CustomfieldvalueSup.findByCustomfield", query = "SELECT c FROM CustomfieldvalueSup c WHERE c.customfield = :customfield"),
    @NamedQuery(name = "CustomfieldvalueSup.findByParentkey", query = "SELECT c FROM CustomfieldvalueSup c WHERE c.parentkey = :parentkey"),
    @NamedQuery(name = "CustomfieldvalueSup.findByStringvalue", query = "SELECT c FROM CustomfieldvalueSup c WHERE c.stringvalue = :stringvalue"),
    @NamedQuery(name = "CustomfieldvalueSup.findByNumbervalue", query = "SELECT c FROM CustomfieldvalueSup c WHERE c.numbervalue = :numbervalue"),
    @NamedQuery(name = "CustomfieldvalueSup.findByDatevalue", query = "SELECT c FROM CustomfieldvalueSup c WHERE c.datevalue = :datevalue"),
    @NamedQuery(name = "CustomfieldvalueSup.findByValuetype", query = "SELECT c FROM CustomfieldvalueSup c WHERE c.valuetype = :valuetype")})
public class CustomfieldvalueSup implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Column(name = "ISSUE")
    private Long issue;
    @Column(name = "CUSTOMFIELD")
    private Long customfield;
    @Size(max = 255)
    @Column(name = "PARENTKEY")
    private String parentkey;
    @Size(max = 255)
    @Column(name = "STRINGVALUE")
    private String stringvalue;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "NUMBERVALUE")
    private BigDecimal numbervalue;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "TEXTVALUE")
    private String textvalue;
    @Column(name = "DATEVALUE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date datevalue;
    @Size(max = 255)
    @Column(name = "VALUETYPE")
    private String valuetype;

    public CustomfieldvalueSup() {
    }

    public CustomfieldvalueSup(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getIssue() {
        return issue;
    }

    public void setIssue(Long issue) {
        this.issue = issue;
    }

    public Long getCustomfield() {
        return customfield;
    }

    public void setCustomfield(Long customfield) {
        this.customfield = customfield;
    }

    public String getParentkey() {
        return parentkey;
    }

    public void setParentkey(String parentkey) {
        this.parentkey = parentkey;
    }

    public String getStringvalue() {
        return stringvalue;
    }

    public void setStringvalue(String stringvalue) {
        this.stringvalue = stringvalue;
    }

    public BigDecimal getNumbervalue() {
        return numbervalue;
    }

    public void setNumbervalue(BigDecimal numbervalue) {
        this.numbervalue = numbervalue;
    }

    public String getTextvalue() {
        return textvalue;
    }

    public void setTextvalue(String textvalue) {
        this.textvalue = textvalue;
    }

    public Date getDatevalue() {
        return datevalue;
    }

    public void setDatevalue(Date datevalue) {
        this.datevalue = datevalue;
    }

    public String getValuetype() {
        return valuetype;
    }

    public void setValuetype(String valuetype) {
        this.valuetype = valuetype;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CustomfieldvalueSup)) {
            return false;
        }
        CustomfieldvalueSup other = (CustomfieldvalueSup) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jiraconnector.entries.CustomfieldvalueSup[ id=" + id + " ]";
    }
    
}
