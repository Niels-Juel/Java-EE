/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector.entries.jirasup;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "customfieldoption")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CustomfieldoptionSup.findAll", query = "SELECT c FROM CustomfieldoptionSup c"),
    @NamedQuery(name = "CustomfieldoptionSup.findById", query = "SELECT c FROM CustomfieldoptionSup c WHERE c.id = :id"),
    @NamedQuery(name = "CustomfieldoptionSup.findByCustomfield", query = "SELECT c FROM CustomfieldoptionSup c WHERE c.customfield = :customfield"),
    @NamedQuery(name = "CustomfieldoptionSup.findByCustomfieldconfig", query = "SELECT c FROM CustomfieldoptionSup c WHERE c.customfieldconfig = :customfieldconfig"),
    @NamedQuery(name = "CustomfieldoptionSup.findByParentoptionid", query = "SELECT c FROM CustomfieldoptionSup c WHERE c.parentoptionid = :parentoptionid"),
    @NamedQuery(name = "CustomfieldoptionSup.findBySequence", query = "SELECT c FROM CustomfieldoptionSup c WHERE c.sequence = :sequence"),
    @NamedQuery(name = "CustomfieldoptionSup.findByCustomvalue", query = "SELECT c FROM CustomfieldoptionSup c WHERE c.customvalue = :customvalue"),
    @NamedQuery(name = "CustomfieldoptionSup.findByOptiontype", query = "SELECT c FROM CustomfieldoptionSup c WHERE c.optiontype = :optiontype"),
    @NamedQuery(name = "CustomfieldoptionSup.findByDisabled", query = "SELECT c FROM CustomfieldoptionSup c WHERE c.disabled = :disabled")})
public class CustomfieldoptionSup implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Column(name = "CUSTOMFIELD")
    private Long customfield;
    @Column(name = "CUSTOMFIELDCONFIG")
    private Long customfieldconfig;
    @Column(name = "PARENTOPTIONID")
    private Long parentoptionid;
    @Column(name = "SEQUENCE")
    private Long sequence;
    @Size(max = 255)
    @Column(name = "customvalue")
    private String customvalue;
    @Size(max = 60)
    @Column(name = "optiontype")
    private String optiontype;
    @Size(max = 60)
    @Column(name = "disabled")
    private String disabled;

    public CustomfieldoptionSup() {
    }

    public CustomfieldoptionSup(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCustomfield() {
        return customfield;
    }

    public void setCustomfield(Long customfield) {
        this.customfield = customfield;
    }

    public Long getCustomfieldconfig() {
        return customfieldconfig;
    }

    public void setCustomfieldconfig(Long customfieldconfig) {
        this.customfieldconfig = customfieldconfig;
    }

    public Long getParentoptionid() {
        return parentoptionid;
    }

    public void setParentoptionid(Long parentoptionid) {
        this.parentoptionid = parentoptionid;
    }

    public Long getSequence() {
        return sequence;
    }

    public void setSequence(Long sequence) {
        this.sequence = sequence;
    }

    public String getCustomvalue() {
        return customvalue;
    }

    public void setCustomvalue(String customvalue) {
        this.customvalue = customvalue;
    }

    public String getOptiontype() {
        return optiontype;
    }

    public void setOptiontype(String optiontype) {
        this.optiontype = optiontype;
    }

    public String getDisabled() {
        return disabled;
    }

    public void setDisabled(String disabled) {
        this.disabled = disabled;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CustomfieldoptionSup)) {
            return false;
        }
        CustomfieldoptionSup other = (CustomfieldoptionSup) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jiraconnector.entries.CustomfieldoptionSup[ id=" + id + " ]";
    }
    
}
