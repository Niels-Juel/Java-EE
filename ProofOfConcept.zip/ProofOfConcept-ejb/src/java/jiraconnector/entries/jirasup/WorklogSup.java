/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector.entries.jirasup;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "worklog")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "WorklogSup.findAll", query = "SELECT w FROM WorklogSup w"),
    @NamedQuery(name = "WorklogSup.findById", query = "SELECT w FROM WorklogSup w WHERE w.id = :id"),
    @NamedQuery(name = "WorklogSup.findByIssueid", query = "SELECT w FROM WorklogSup w WHERE w.issueid = :issueid"),
    @NamedQuery(name = "WorklogSup.findByAuthor", query = "SELECT w FROM WorklogSup w WHERE w.author = :author"),
    @NamedQuery(name = "WorklogSup.findByGrouplevel", query = "SELECT w FROM WorklogSup w WHERE w.grouplevel = :grouplevel"),
    @NamedQuery(name = "WorklogSup.findByRolelevel", query = "SELECT w FROM WorklogSup w WHERE w.rolelevel = :rolelevel"),
    @NamedQuery(name = "WorklogSup.findByCreated", query = "SELECT w FROM WorklogSup w WHERE w.created = :created"),
    @NamedQuery(name = "WorklogSup.findByUpdateauthor", query = "SELECT w FROM WorklogSup w WHERE w.updateauthor = :updateauthor"),
    @NamedQuery(name = "WorklogSup.findByUpdated", query = "SELECT w FROM WorklogSup w WHERE w.updated = :updated"),
    @NamedQuery(name = "WorklogSup.findByStartdate", query = "SELECT w FROM WorklogSup w WHERE w.startdate = :startdate"),
    @NamedQuery(name = "WorklogSup.findByTimeworked", query = "SELECT w FROM WorklogSup w WHERE w.timeworked = :timeworked")})
public class WorklogSup implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Column(name = "issueid")
    private Long issueid;
    @Size(max = 255)
    @Column(name = "AUTHOR")
    private String author;
    @Size(max = 255)
    @Column(name = "grouplevel")
    private String grouplevel;
    @Column(name = "rolelevel")
    private Long rolelevel;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "worklogbody")
    private String worklogbody;
    @Column(name = "CREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;
    @Size(max = 255)
    @Column(name = "UPDATEAUTHOR")
    private String updateauthor;
    @Column(name = "UPDATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updated;
    @Column(name = "STARTDATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date startdate;
    @Column(name = "timeworked")
    private Long timeworked;
    
//    @ManyToOne
//    @JoinColumn(name = "issueid", insertable = false, updatable = false)
//    private Jiraissue jiraissue;

    public WorklogSup() {
    }

    public WorklogSup(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getIssueid() {
        return issueid;
    }

    public void setIssueid(Long issueid) {
        this.issueid = issueid;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGrouplevel() {
        return grouplevel;
    }

    public void setGrouplevel(String grouplevel) {
        this.grouplevel = grouplevel;
    }

    public Long getRolelevel() {
        return rolelevel;
    }

    public void setRolelevel(Long rolelevel) {
        this.rolelevel = rolelevel;
    }

    public String getWorklogbody() {
        return worklogbody;
    }

    public void setWorklogbody(String worklogbody) {
        this.worklogbody = worklogbody;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public String getUpdateauthor() {
        return updateauthor;
    }

    public void setUpdateauthor(String updateauthor) {
        this.updateauthor = updateauthor;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public Date getStartdate() {
        return startdate;
    }

    public void setStartdate(Date startdate) {
        this.startdate = startdate;
    }

    public Long getTimeworked() {
        return timeworked;
    }

    public void setTimeworked(Long timeworked) {
        this.timeworked = timeworked;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof WorklogSup)) {
            return false;
        }
        WorklogSup other = (WorklogSup) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jiraconnector.entries.WorklogSup[ id=" + id + " ]";
    }
    
}
