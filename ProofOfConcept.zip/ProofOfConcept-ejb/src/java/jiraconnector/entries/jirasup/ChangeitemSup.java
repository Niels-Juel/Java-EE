/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector.entries.jirasup;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "changeitem")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ChangeitemSup.findAll", query = "SELECT c FROM ChangeitemSup c"),
    @NamedQuery(name = "ChangeitemSup.findById", query = "SELECT c FROM ChangeitemSup c WHERE c.id = :id"),
    @NamedQuery(name = "ChangeitemSup.findByGroupid", query = "SELECT c FROM ChangeitemSup c WHERE c.groupid = :groupid"),
    @NamedQuery(name = "ChangeitemSup.findByGroupidField", 
            query = "SELECT c FROM ChangeitemSup c WHERE c.groupid = :groupid AND c.field = :field"),
    @NamedQuery(name = "ChangeitemSup.findByFieldtype", query = "SELECT c FROM ChangeitemSup c WHERE c.fieldtype = :fieldtype"),
    @NamedQuery(name = "ChangeitemSup.findByField", query = "SELECT c FROM ChangeitemSup c WHERE c.field = :field")})
public class ChangeitemSup implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Column(name = "groupid")
    private Long groupid;
    @Size(max = 255)
    @Column(name = "FIELDTYPE")
    private String fieldtype;
    @Size(max = 255)
    @Column(name = "FIELD")
    private String field;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "OLDVALUE")
    private String oldvalue;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "OLDSTRING")
    private String oldstring;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "NEWVALUE")
    private String newvalue;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "NEWSTRING")
    private String newstring;

    public ChangeitemSup() {
    }

    public ChangeitemSup(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getGroupid() {
        return groupid;
    }

    public void setGroupid(Long groupid) {
        this.groupid = groupid;
    }

    public String getFieldtype() {
        return fieldtype;
    }

    public void setFieldtype(String fieldtype) {
        this.fieldtype = fieldtype;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getOldvalue() {
        return oldvalue;
    }

    public void setOldvalue(String oldvalue) {
        this.oldvalue = oldvalue;
    }

    public String getOldstring() {
        return oldstring;
    }

    public void setOldstring(String oldstring) {
        this.oldstring = oldstring;
    }

    public String getNewvalue() {
        return newvalue;
    }

    public void setNewvalue(String newvalue) {
        this.newvalue = newvalue;
    }

    public String getNewstring() {
        return newstring;
    }

    public void setNewstring(String newstring) {
        this.newstring = newstring;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ChangeitemSup)) {
            return false;
        }
        ChangeitemSup other = (ChangeitemSup) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jiraconnector.entries.ChangeitemSup[ id=" + id + " ]";
    }
    
}
