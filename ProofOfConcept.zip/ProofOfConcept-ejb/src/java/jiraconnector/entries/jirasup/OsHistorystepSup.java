/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector.entries.jirasup;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "OS_HISTORYSTEP")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "OsHistorystepSup.findAll", query = "SELECT o FROM OsHistorystepSup o"),
    @NamedQuery(name = "OsHistorystepSup.findById", query = "SELECT o FROM OsHistorystepSup o WHERE o.id = :id"),
    @NamedQuery(name = "OsHistorystepSup.findByEntryId", query = "SELECT o FROM OsHistorystepSup o WHERE o.entryId = :entryId"),
    @NamedQuery(name = "OsHistorystepSup.findByStepId", query = "SELECT o FROM OsHistorystepSup o WHERE o.stepId = :stepId"),
    @NamedQuery(name = "OsHistorystepSup.findByActionId", query = "SELECT o FROM OsHistorystepSup o WHERE o.actionId = :actionId"),
    @NamedQuery(name = "OsHistorystepSup.findByOwner", query = "SELECT o FROM OsHistorystepSup o WHERE o.owner = :owner"),
    @NamedQuery(name = "OsHistorystepSup.findByStartDate", query = "SELECT o FROM OsHistorystepSup o WHERE o.startDate = :startDate"),
    @NamedQuery(name = "OsHistorystepSup.findByDueDate", query = "SELECT o FROM OsHistorystepSup o WHERE o.dueDate = :dueDate"),
    @NamedQuery(name = "OsHistorystepSup.findByFinishDate", query = "SELECT o FROM OsHistorystepSup o WHERE o.finishDate = :finishDate"),
    @NamedQuery(name = "OsHistorystepSup.findByStatus", query = "SELECT o FROM OsHistorystepSup o WHERE o.status = :status"),
    @NamedQuery(name = "OsHistorystepSup.findByStatusEntryId", 
            query = "SELECT o FROM OsHistorystepSup o WHERE o.stepId IN :stepIds AND o.entryId = :entryId ORDER BY o.id"),
    @NamedQuery(name = "OsHistorystepSup.findByCaller", query = "SELECT o FROM OsHistorystepSup o WHERE o.caller = :caller")})
public class OsHistorystepSup implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Column(name = "ENTRY_ID")
    private Long entryId;
    @Column(name = "STEP_ID")
    private Integer stepId;
    @Column(name = "ACTION_ID")
    private Integer actionId;
    @Size(max = 60)
    @Column(name = "OWNER")
    private String owner;
    @Column(name = "START_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date startDate;
    @Column(name = "DUE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dueDate;
    @Column(name = "FINISH_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date finishDate;
    @Size(max = 60)
    @Column(name = "STATUS")
    private String status;
    @Size(max = 60)
    @Column(name = "CALLER")
    private String caller;

    public OsHistorystepSup() {
    }

    public OsHistorystepSup(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getEntryId() {
        return entryId;
    }

    public void setEntryId(Long entryId) {
        this.entryId = entryId;
    }

    public Integer getStepId() {
        return stepId;
    }

    public void setStepId(Integer stepId) {
        this.stepId = stepId;
    }

    public Integer getActionId() {
        return actionId;
    }

    public void setActionId(Integer actionId) {
        this.actionId = actionId;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public Date getFinishDate() {
        return finishDate;
    }

    public void setFinishDate(Date finishDate) {
        this.finishDate = finishDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCaller() {
        return caller;
    }

    public void setCaller(String caller) {
        this.caller = caller;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof OsHistorystepSup)) {
            return false;
        }
        OsHistorystepSup other = (OsHistorystepSup) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jiraconnector.entries.OsHistorystepSup[ id=" + id + " ]";
    }
    
}
