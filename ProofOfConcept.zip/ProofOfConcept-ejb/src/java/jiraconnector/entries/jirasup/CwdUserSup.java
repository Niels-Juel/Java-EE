/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector.entries.jirasup;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "cwd_user")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CwdUserSup.findAll", query = "SELECT c FROM CwdUserSup c ORDER BY c.displayName"),
    @NamedQuery(name = "CwdUserSup.findById", query = "SELECT c FROM CwdUserSup c WHERE c.id = :id"),
    @NamedQuery(name = "CwdUserSup.findByDirectoryId", query = "SELECT c FROM CwdUserSup c WHERE c.directoryId = :directoryId"),
    @NamedQuery(name = "CwdUserSup.findByUserName", query = "SELECT c FROM CwdUserSup c WHERE c.userName = :userName"),
    @NamedQuery(name = "CwdUserSup.findByUserNameLike", query = "SELECT c FROM CwdUserSup c WHERE c.userName LIKE :userName"),
    @NamedQuery(name = "CwdUserSup.findByLowerUserName", query = "SELECT c FROM CwdUserSup c WHERE c.lowerUserName = :lowerUserName"),
    @NamedQuery(name = "CwdUserSup.findByActive", query = "SELECT c FROM CwdUserSup c WHERE c.active = :active"),
    @NamedQuery(name = "CwdUserSup.findByCreatedDate", query = "SELECT c FROM CwdUserSup c WHERE c.createdDate = :createdDate"),
    @NamedQuery(name = "CwdUserSup.findByUpdatedDate", query = "SELECT c FROM CwdUserSup c WHERE c.updatedDate = :updatedDate"),
    @NamedQuery(name = "CwdUserSup.findByFirstName", query = "SELECT c FROM CwdUserSup c WHERE c.firstName = :firstName"),
    @NamedQuery(name = "CwdUserSup.findByLowerFirstName", query = "SELECT c FROM CwdUserSup c WHERE c.lowerFirstName = :lowerFirstName"),
    @NamedQuery(name = "CwdUserSup.findByLastName", query = "SELECT c FROM CwdUserSup c WHERE c.lastName = :lastName"),
    @NamedQuery(name = "CwdUserSup.findByLowerLastName", query = "SELECT c FROM CwdUserSup c WHERE c.lowerLastName = :lowerLastName"),
    @NamedQuery(name = "CwdUserSup.findByDisplayName", query = "SELECT c FROM CwdUserSup c WHERE c.displayName = :displayName"),
    @NamedQuery(name = "CwdUserSup.findByLowerDisplayName", query = "SELECT c FROM CwdUserSup c WHERE c.lowerDisplayName = :lowerDisplayName"),
    @NamedQuery(name = "CwdUserSup.findByEmailAddress", query = "SELECT c FROM CwdUserSup c WHERE c.emailAddress = :emailAddress"),
    @NamedQuery(name = "CwdUserSup.findByLowerEmailAddress", query = "SELECT c FROM CwdUserSup c WHERE c.lowerEmailAddress = :lowerEmailAddress"),
    @NamedQuery(name = "CwdUserSup.findByCredential", query = "SELECT c FROM CwdUserSup c WHERE c.credential = :credential")})
public class CwdUserSup implements Serializable, Comparable<CwdUserSup> {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Column(name = "directory_id")
    private Long directoryId;
    @Size(max = 255)
    @Column(name = "user_name")
    private String userName;
    @Size(max = 255)
    @Column(name = "lower_user_name")
    private String lowerUserName;
    @Column(name = "active")
    private Integer active;
    @Column(name = "created_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;
    @Column(name = "updated_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedDate;
    @Size(max = 255)
    @Column(name = "first_name")
    private String firstName;
    @Size(max = 255)
    @Column(name = "lower_first_name")
    private String lowerFirstName;
    @Size(max = 255)
    @Column(name = "last_name")
    private String lastName;
    @Size(max = 255)
    @Column(name = "lower_last_name")
    private String lowerLastName;
    @Size(max = 255)
    @Column(name = "display_name")
    private String displayName;
    @Size(max = 255)
    @Column(name = "lower_display_name")
    private String lowerDisplayName;
    @Size(max = 255)
    @Column(name = "email_address")
    private String emailAddress;
    @Size(max = 255)
    @Column(name = "lower_email_address")
    private String lowerEmailAddress;
    @Size(max = 255)
    @Column(name = "CREDENTIAL")
    private String credential;

    public CwdUserSup() {
    }

    public CwdUserSup(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getDirectoryId() {
        return directoryId;
    }

    public void setDirectoryId(Long directoryId) {
        this.directoryId = directoryId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getLowerUserName() {
        return lowerUserName;
    }

    public void setLowerUserName(String lowerUserName) {
        this.lowerUserName = lowerUserName;
    }

    public Integer getActive() {
        return active;
    }

    public void setActive(Integer active) {
        this.active = active;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLowerFirstName() {
        return lowerFirstName;
    }

    public void setLowerFirstName(String lowerFirstName) {
        this.lowerFirstName = lowerFirstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLowerLastName() {
        return lowerLastName;
    }

    public void setLowerLastName(String lowerLastName) {
        this.lowerLastName = lowerLastName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getLowerDisplayName() {
        return lowerDisplayName;
    }

    public void setLowerDisplayName(String lowerDisplayName) {
        this.lowerDisplayName = lowerDisplayName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getLowerEmailAddress() {
        return lowerEmailAddress;
    }

    public void setLowerEmailAddress(String lowerEmailAddress) {
        this.lowerEmailAddress = lowerEmailAddress;
    }

    public String getCredential() {
        return credential;
    }

    public void setCredential(String credential) {
        this.credential = credential;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CwdUserSup)) {
            return false;
        }
        CwdUserSup other = (CwdUserSup) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return displayName+" "+userName;
    }
    
    @Override
    public int compareTo(CwdUserSup cwdUserSup) {
        return this.userName.compareTo(cwdUserSup.getUserName());
    }
}
