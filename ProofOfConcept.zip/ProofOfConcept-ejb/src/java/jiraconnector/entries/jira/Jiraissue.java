/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector.entries.jira;

import java.io.Serializable;
import java.util.*;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import jiraconnector.EmploymentInterval;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "jiraissue", catalog = "jira", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Jiraissue.findAll", query = "SELECT j FROM Jiraissue j"),
    @NamedQuery(name = "Jiraissue.findById", query = "SELECT j FROM Jiraissue j WHERE j.id = :id"),
    @NamedQuery(name = "Jiraissue.findByPkey", query = "SELECT j FROM Jiraissue j WHERE j.pkey = :pkey"),
    @NamedQuery(name = "Jiraissue.findByProject", query = "SELECT j FROM Jiraissue j WHERE j.project = :project"),
    @NamedQuery(name = "Jiraissue.findByReporter", query = "SELECT j FROM Jiraissue j WHERE j.reporter = :reporter"),
    @NamedQuery(name = "Jiraissue.findByAssignee", query = "SELECT j FROM Jiraissue j WHERE j.assignee = :assignee"),
    @NamedQuery(name = "Jiraissue.findByIssuetype", query = "SELECT j FROM Jiraissue j WHERE j.issuetype = :issuetype"),
    @NamedQuery(name = "Jiraissue.findBySummary", query = "SELECT j FROM Jiraissue j WHERE j.summary = :summary"),
    @NamedQuery(name = "Jiraissue.findByPriority", query = "SELECT j FROM Jiraissue j WHERE j.priority = :priority"),
    @NamedQuery(name = "Jiraissue.findByResolution", query = "SELECT j FROM Jiraissue j WHERE j.resolution = :resolution"),
    @NamedQuery(name = "Jiraissue.findByIssuestatus", query = "SELECT j FROM Jiraissue j WHERE j.issuestatus = :issuestatus"),
    @NamedQuery(name = "Jiraissue.findByCreated", query = "SELECT j FROM Jiraissue j WHERE j.created = :created"),
    @NamedQuery(name = "Jiraissue.findByUpdated", query = "SELECT j FROM Jiraissue j WHERE j.updated = :updated"),
    @NamedQuery(name = "Jiraissue.findByDuedate", query = "SELECT j FROM Jiraissue j WHERE j.duedate = :duedate"),
    @NamedQuery(name = "Jiraissue.findByResolutiondate", query = "SELECT j FROM Jiraissue j WHERE j.resolutiondate = :resolutiondate"),
    @NamedQuery(name = "Jiraissue.findByVotes", query = "SELECT j FROM Jiraissue j WHERE j.votes = :votes"),
    @NamedQuery(name = "Jiraissue.findByWatches", query = "SELECT j FROM Jiraissue j WHERE j.watches = :watches"),
    @NamedQuery(name = "Jiraissue.findByTimeoriginalestimate", query = "SELECT j FROM Jiraissue j WHERE j.timeoriginalestimate = :timeoriginalestimate"),
    @NamedQuery(name = "Jiraissue.findByTimeestimate", query = "SELECT j FROM Jiraissue j WHERE j.timeestimate = :timeestimate"),
    @NamedQuery(name = "Jiraissue.findByTimespent", query = "SELECT j FROM Jiraissue j WHERE j.timespent = :timespent"),
    @NamedQuery(name = "Jiraissue.findByWorkflowId", query = "SELECT j FROM Jiraissue j WHERE j.workflowId = :workflowId"),
    @NamedQuery(name = "Jiraissue.findBySecurity", query = "SELECT j FROM Jiraissue j WHERE j.security = :security"),
    @NamedQuery(name = "Jiraissue.findByFixfor", query = "SELECT j FROM Jiraissue j WHERE j.fixfor = :fixfor"),
    @NamedQuery(name = "Jiraissue.findByComponent", query = "SELECT j FROM Jiraissue j WHERE j.component = :component")})
public class Jiraissue implements Serializable, Comparable<Jiraissue> {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Size(max = 255)
    @Column(name = "pkey")
    private String pkey;
    @Column(name = "PROJECT")
    private Long project;
    @Size(max = 255)
    @Column(name = "REPORTER")
    private String reporter;
    @Size(max = 255)
    @Column(name = "ASSIGNEE")
    private String assignee;
    @Size(max = 255)
    @Column(name = "issuetype")
    private String issuetype;
    @Size(max = 255)
    @Column(name = "SUMMARY")
    private String summary;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "DESCRIPTION")
    private String description;
    @Lob
    @Size(max = 2147483647)
    @Column(name = "ENVIRONMENT")
    private String environment;
    @Size(max = 255)
    @Column(name = "PRIORITY")
    private String priority;
    @Size(max = 255)
    @Column(name = "RESOLUTION")
    private String resolution;
    @Size(max = 255)
    @Column(name = "issuestatus")
    private String issuestatus;
    @Column(name = "CREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;
    @Column(name = "UPDATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updated;
    @Column(name = "DUEDATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date duedate;
    @Column(name = "RESOLUTIONDATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date resolutiondate;
    @Column(name = "VOTES")
    private Long votes;
    @Column(name = "WATCHES")
    private Long watches;
    @Column(name = "TIMEORIGINALESTIMATE")
    private Long timeoriginalestimate;
    @Column(name = "TIMEESTIMATE")
    private Long timeestimate;
    @Column(name = "TIMESPENT")
    private Long timespent;
    @Column(name = "WORKFLOW_ID")
    private Long workflowId;
    @Column(name = "SECURITY")
    private Long security;
    @Column(name = "FIXFOR")
    private Long fixfor;
    @Column(name = "COMPONENT")
    private Long component;

    @Transient
    private final Map<String, String> customFields;
    
    @Transient
    private final List<EmploymentInterval> employmentIntervals;
    
    public Jiraissue() {
        customFields=new HashMap<>();
        employmentIntervals=new ArrayList<>();
    }

    public Jiraissue(Long id) {
        this.id = id;
        customFields=new HashMap<>();
        employmentIntervals=new ArrayList<>();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPkey() {
        return pkey;
    }

    public void setPkey(String pkey) {
        this.pkey = pkey;
    }

    public Long getProject() {
        return project;
    }

    public void setProject(Long project) {
        this.project = project;
    }

    public String getReporter() {
        return reporter;
    }

    public void setReporter(String reporter) {
        this.reporter = reporter;
    }

    public String getAssignee() {
        return assignee;
    }

    public void setAssignee(String assignee) {
        this.assignee = assignee;
    }

    public String getIssuetype() {
        return issuetype;
    }

    public void setIssuetype(String issuetype) {
        this.issuetype = issuetype;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getResolution() {
        return resolution;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    public String getIssuestatus() {
        return issuestatus;
    }

    public void setIssuestatus(String issuestatus) {
        this.issuestatus = issuestatus;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public Date getDuedate() {
        return duedate;
    }

    public void setDuedate(Date duedate) {
        this.duedate = duedate;
    }

    public Date getResolutiondate() {
        return resolutiondate;
    }

    public void setResolutiondate(Date resolutiondate) {
        this.resolutiondate = resolutiondate;
    }

    public Long getVotes() {
        return votes;
    }

    public void setVotes(Long votes) {
        this.votes = votes;
    }

    public Long getWatches() {
        return watches;
    }

    public void setWatches(Long watches) {
        this.watches = watches;
    }

    public Long getTimeoriginalestimate() {
        if (timeoriginalestimate!=null) {
            return timeoriginalestimate;
        } else {
            return 0l;
        }
    }

    public void setTimeoriginalestimate(Long timeoriginalestimate) {
        this.timeoriginalestimate = timeoriginalestimate;
    }

    public Long getTimeestimate() {
        return timeestimate;
    }

    public void setTimeestimate(Long timeestimate) {
        this.timeestimate = timeestimate;
    }

    public Long getTimespent() {
        return timespent;
    }

    public void setTimespent(Long timespent) {
        this.timespent = timespent;
    }

    public Long getWorkflowId() {
        return workflowId;
    }

    public void setWorkflowId(Long workflowId) {
        this.workflowId = workflowId;
    }

    public Long getSecurity() {
        return security;
    }

    public void setSecurity(Long security) {
        this.security = security;
    }

    public Long getFixfor() {
        return fixfor;
    }

    public void setFixfor(Long fixfor) {
        this.fixfor = fixfor;
    }

    public Long getComponent() {
        return component;
    }

    public void setComponent(Long component) {
        this.component = component;
    }

    public Map<String, String> getCustomFields() {
        return customFields;
    }

    public List<EmploymentInterval> getEmploymentIntervals() {
        return employmentIntervals;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Jiraissue)) {
            return false;
        }
        Jiraissue other = (Jiraissue) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return summary;
    }

    @Override
    public int compareTo(Jiraissue jiraissue) {
        return this.summary.compareTo(jiraissue.getSummary());
    }
}
