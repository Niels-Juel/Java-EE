/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector.entries.jira;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "changegroup")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Changegroup.findAll", query = "SELECT c FROM Changegroup c"),
    @NamedQuery(name = "Changegroup.findById", query = "SELECT c FROM Changegroup c WHERE c.id = :id"),
    @NamedQuery(name = "Changegroup.findByIssueid", query = "SELECT c FROM Changegroup c WHERE c.issueid = :issueid"),
    @NamedQuery(name = "Changegroup.findByAuthor", query = "SELECT c FROM Changegroup c WHERE c.author = :author"),
    @NamedQuery(name = "Changegroup.findByCreated", query = "SELECT c FROM Changegroup c WHERE c.created = :created")})
public class Changegroup implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Column(name = "issueid")
    private Long issueid;
    @Size(max = 255)
    @Column(name = "AUTHOR")
    private String author;
    @Column(name = "CREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;

    public Changegroup() {
    }

    public Changegroup(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getIssueid() {
        return issueid;
    }

    public void setIssueid(Long issueid) {
        this.issueid = issueid;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Changegroup)) {
            return false;
        }
        Changegroup other = (Changegroup) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jiraconnector.entries.Changegroup[ id=" + id + " ]";
    }
    
}
