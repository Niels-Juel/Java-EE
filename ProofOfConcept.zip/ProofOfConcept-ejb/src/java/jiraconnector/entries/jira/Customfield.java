/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector.entries.jira;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "customfield")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Customfield.findAll", query = "SELECT c FROM Customfield c"),
    @NamedQuery(name = "Customfield.findById", query = "SELECT c FROM Customfield c WHERE c.id = :id"),
    @NamedQuery(name = "Customfield.findByCustomfieldtypekey", query = "SELECT c FROM Customfield c WHERE c.customfieldtypekey = :customfieldtypekey"),
    @NamedQuery(name = "Customfield.findByCustomfieldsearcherkey", query = "SELECT c FROM Customfield c WHERE c.customfieldsearcherkey = :customfieldsearcherkey"),
    @NamedQuery(name = "Customfield.findByCfname", query = "SELECT c FROM Customfield c WHERE c.cfname = :cfname"),
    @NamedQuery(name = "Customfield.findByDefaultvalue", query = "SELECT c FROM Customfield c WHERE c.defaultvalue = :defaultvalue"),
    @NamedQuery(name = "Customfield.findByFieldtype", query = "SELECT c FROM Customfield c WHERE c.fieldtype = :fieldtype"),
    @NamedQuery(name = "Customfield.findByProject", query = "SELECT c FROM Customfield c WHERE c.project = :project"),
    @NamedQuery(name = "Customfield.findByIssuetype", query = "SELECT c FROM Customfield c WHERE c.issuetype = :issuetype")})
public class Customfield implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Size(max = 255)
    @Column(name = "CUSTOMFIELDTYPEKEY")
    private String customfieldtypekey;
    @Size(max = 255)
    @Column(name = "CUSTOMFIELDSEARCHERKEY")
    private String customfieldsearcherkey;
    @Size(max = 255)
    @Column(name = "cfname")
    private String cfname;
    @Lob
    @Size(max = 65535)
    @Column(name = "DESCRIPTION")
    private String description;
    @Size(max = 255)
    @Column(name = "defaultvalue")
    private String defaultvalue;
    @Column(name = "FIELDTYPE")
    private Long fieldtype;
    @Column(name = "PROJECT")
    private Long project;
    @Size(max = 255)
    @Column(name = "ISSUETYPE")
    private String issuetype;

    public Customfield() {
    }

    public Customfield(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustomfieldtypekey() {
        return customfieldtypekey;
    }

    public void setCustomfieldtypekey(String customfieldtypekey) {
        this.customfieldtypekey = customfieldtypekey;
    }

    public String getCustomfieldsearcherkey() {
        return customfieldsearcherkey;
    }

    public void setCustomfieldsearcherkey(String customfieldsearcherkey) {
        this.customfieldsearcherkey = customfieldsearcherkey;
    }

    public String getCfname() {
        return cfname;
    }

    public void setCfname(String cfname) {
        this.cfname = cfname;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDefaultvalue() {
        return defaultvalue;
    }

    public void setDefaultvalue(String defaultvalue) {
        this.defaultvalue = defaultvalue;
    }

    public Long getFieldtype() {
        return fieldtype;
    }

    public void setFieldtype(Long fieldtype) {
        this.fieldtype = fieldtype;
    }

    public Long getProject() {
        return project;
    }

    public void setProject(Long project) {
        this.project = project;
    }

    public String getIssuetype() {
        return issuetype;
    }

    public void setIssuetype(String issuetype) {
        this.issuetype = issuetype;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Customfield)) {
            return false;
        }
        Customfield other = (Customfield) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jiraconnector.entries.Customfield[ id=" + id + " ]";
    }
    
}
