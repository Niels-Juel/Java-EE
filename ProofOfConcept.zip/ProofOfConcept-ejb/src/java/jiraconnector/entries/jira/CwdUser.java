/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector.entries.jira;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author a.shalin
 */
@Entity
@Table(name = "cwd_user", catalog = "jira", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CwdUser.findAll", query = "SELECT c FROM CwdUser c ORDER BY c.displayName"),
    @NamedQuery(name = "CwdUser.findById", query = "SELECT c FROM CwdUser c WHERE c.id = :id"),
    @NamedQuery(name = "CwdUser.findByDirectoryId", query = "SELECT c FROM CwdUser c WHERE c.directoryId = :directoryId"),
    @NamedQuery(name = "CwdUser.findByUserName", query = "SELECT c FROM CwdUser c WHERE c.userName = :userName"),
    @NamedQuery(name = "CwdUser.findByUserNameLike", query = "SELECT c FROM CwdUser c WHERE c.userName LIKE :userName"),
    @NamedQuery(name = "CwdUser.findByLowerUserName", query = "SELECT c FROM CwdUser c WHERE c.lowerUserName = :lowerUserName"),
    @NamedQuery(name = "CwdUser.findByActive", query = "SELECT c FROM CwdUser c WHERE c.active = :active"),
    @NamedQuery(name = "CwdUser.findByCreatedDate", query = "SELECT c FROM CwdUser c WHERE c.createdDate = :createdDate"),
    @NamedQuery(name = "CwdUser.findByUpdatedDate", query = "SELECT c FROM CwdUser c WHERE c.updatedDate = :updatedDate"),
    @NamedQuery(name = "CwdUser.findByFirstName", query = "SELECT c FROM CwdUser c WHERE c.firstName = :firstName"),
    @NamedQuery(name = "CwdUser.findByLowerFirstName", query = "SELECT c FROM CwdUser c WHERE c.lowerFirstName = :lowerFirstName"),
    @NamedQuery(name = "CwdUser.findByLastName", query = "SELECT c FROM CwdUser c WHERE c.lastName = :lastName"),
    @NamedQuery(name = "CwdUser.findByLowerLastName", query = "SELECT c FROM CwdUser c WHERE c.lowerLastName = :lowerLastName"),
    @NamedQuery(name = "CwdUser.findByDisplayName", query = "SELECT c FROM CwdUser c WHERE c.displayName = :displayName"),
    @NamedQuery(name = "CwdUser.findByLowerDisplayName", query = "SELECT c FROM CwdUser c WHERE c.lowerDisplayName = :lowerDisplayName"),
    @NamedQuery(name = "CwdUser.findByEmailAddress", query = "SELECT c FROM CwdUser c WHERE c.emailAddress = :emailAddress"),
    @NamedQuery(name = "CwdUser.findByLowerEmailAddress", query = "SELECT c FROM CwdUser c WHERE c.lowerEmailAddress = :lowerEmailAddress"),
    @NamedQuery(name = "CwdUser.findByCredential", query = "SELECT c FROM CwdUser c WHERE c.credential = :credential")})
public class CwdUser implements Serializable, Comparable<CwdUser> {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Column(name = "directory_id")
    private Long directoryId;
    @Size(max = 255)
    @Column(name = "user_name")
    private String userName;
    @Size(max = 255)
    @Column(name = "lower_user_name")
    private String lowerUserName;
    @Column(name = "active")
    private Integer active;
    @Column(name = "created_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;
    @Column(name = "updated_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedDate;
    @Size(max = 255)
    @Column(name = "first_name")
    private String firstName;
    @Size(max = 255)
    @Column(name = "lower_first_name")
    private String lowerFirstName;
    @Size(max = 255)
    @Column(name = "last_name")
    private String lastName;
    @Size(max = 255)
    @Column(name = "lower_last_name")
    private String lowerLastName;
    @Size(max = 255)
    @Column(name = "display_name")
    private String displayName;
    @Size(max = 255)
    @Column(name = "lower_display_name")
    private String lowerDisplayName;
    @Size(max = 255)
    @Column(name = "email_address")
    private String emailAddress;
    @Size(max = 255)
    @Column(name = "lower_email_address")
    private String lowerEmailAddress;
    @Size(max = 255)
    @Column(name = "CREDENTIAL")
    private String credential;

    public CwdUser() {
    }

    public CwdUser(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getDirectoryId() {
        return directoryId;
    }

    public void setDirectoryId(Long directoryId) {
        this.directoryId = directoryId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getLowerUserName() {
        return lowerUserName;
    }

    public void setLowerUserName(String lowerUserName) {
        this.lowerUserName = lowerUserName;
    }

    public Integer getActive() {
        return active;
    }

    public void setActive(Integer active) {
        this.active = active;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLowerFirstName() {
        return lowerFirstName;
    }

    public void setLowerFirstName(String lowerFirstName) {
        this.lowerFirstName = lowerFirstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLowerLastName() {
        return lowerLastName;
    }

    public void setLowerLastName(String lowerLastName) {
        this.lowerLastName = lowerLastName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getLowerDisplayName() {
        return lowerDisplayName;
    }

    public void setLowerDisplayName(String lowerDisplayName) {
        this.lowerDisplayName = lowerDisplayName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getLowerEmailAddress() {
        return lowerEmailAddress;
    }

    public void setLowerEmailAddress(String lowerEmailAddress) {
        this.lowerEmailAddress = lowerEmailAddress;
    }

    public String getCredential() {
        return credential;
    }

    public void setCredential(String credential) {
        this.credential = credential;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CwdUser)) {
            return false;
        }
        CwdUser other = (CwdUser) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return displayName+" "+userName;
    }
    
    @Override
    public int compareTo(CwdUser cwdUser) {
        return this.userName.compareTo(cwdUser.getUserName());
    }
}
