/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector;

import java.io.Serializable;
import java.util.*;

/**
 *
 * @author a.shalin
 */
public class UserReportBlock implements Serializable, Comparable<UserReportBlock> {
    private final List<UserReportEntry> userReportEntries;
    private String userDisplayName;
    private long laborExpenditures, laborExpendituresPlanned;

    public String getUserDisplayName() {
        return userDisplayName;
    }

    public void setUserDisplayName(String userDisplayName) {
        this.userDisplayName = userDisplayName;
    }

    public long getLaborExpenditures() {
        return laborExpenditures;
    }

    public void setLaborExpenditures(long laborExpenditures) {
        this.laborExpenditures = laborExpenditures;
    }

    public long getLaborExpendituresPlanned() {
        return laborExpendituresPlanned;
    }

    public void setLaborExpendituresPlanned(long laborExpendituresPlanned) {
        this.laborExpendituresPlanned = laborExpendituresPlanned;
    }

    public List<UserReportEntry> getUserReportEntries() {
        return userReportEntries;
    }
    
    public UserReportBlock() {
        this.userReportEntries=new ArrayList<>();
        this.laborExpenditures=0;
        this.laborExpendituresPlanned=0;
    }
    
    public UserReportBlock(String userDisplayName) {
        this.laborExpenditures=0;
        this.laborExpendituresPlanned=0;
        this.userDisplayName=userDisplayName;
        this.userReportEntries=new ArrayList<>();
    }

    @Override
    public int compareTo(UserReportBlock userReportBlock) {
        return this.userDisplayName.compareTo(userReportBlock.getUserDisplayName());
    }
}
