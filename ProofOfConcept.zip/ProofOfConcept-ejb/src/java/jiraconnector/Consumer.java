/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jiraconnector;

import java.io.IOException;
import java.io.Serializable;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
/**
 *
 * @author a.shalin
 */
@Stateless
@LocalBean
public class Consumer implements Serializable{
//    private final Client client;
    private final String user, password;
    private String testMessage;
    
    public String getTestMessage() {
        return testMessage;
    }

    public void setTestMessage(String testMessage) {
        this.testMessage = testMessage;
    }
    
    public Consumer() throws IOException{
        user="a.shalin"; password="AlienHighway1488"; testMessage="";
//
//        CloseableHttpClient httpClient=HttpClients.createDefault();
//        Credentials defaultCreds=new UsernamePasswordCredentials(user, password);
//        
//        HttpHost targetHost=new HttpHost("jira.rambler.ru", 443, "https");
//        CredentialsProvider credsProvider=new BasicCredentialsProvider();
//        credsProvider.setCredentials(new AuthScope(targetHost.getHostName(), targetHost.getPort()), defaultCreds);
//        
//        //Create AutoCash instance
//        AuthCache authCache=new BasicAuthCache();
//        BasicScheme basicAuth=new BasicScheme();
//        authCache.put(targetHost, basicAuth);
//        
//        //Add AuthCache to the execution context
//        HttpClientContext context =HttpClientContext.create();
//        context.setCredentialsProvider(credsProvider);
//        context.setAuthCache(authCache);
//        
//        HttpGet httpGet=new HttpGet("/rest/api/2/issue/TESTWORK-7");
//        CloseableHttpResponse response=httpClient.execute(targetHost, httpGet, context);
//        try {
//            HttpEntity entity=response.getEntity(); 
//            InputStream input=entity.getContent();
//            
//            JsonReader jsonReader=Json.createReader(input);
//            JsonObject jsonObject=jsonReader.readObject();
//            jsonReader.close();
//            input.close();
//            
////            testMessage=jsonObject.getJsonObject("fields").getJsonObject("timetracking").getString("originalEstimate").toString();
////            testMessage=jsonObject.getJsonObject("fields").getString("description", "Blah!");
//            testMessage="";
//            JsonArray commentsArray=jsonObject.getJsonObject("fields").getJsonObject("comment").getJsonArray("comments");
//            for (JsonValue commentRaw: commentsArray) {
//                JsonObject commentObject=(JsonObject) commentRaw;
//                testMessage+=(commentObject.getString("body", "").toString()+"\n");
//            }
//            
//        } catch (ClassCastException ex) {
//            testMessage="Couldn't parse field";
//            ex.printStackTrace();
//        } finally {
//            response.close();
//        }
    }
}
